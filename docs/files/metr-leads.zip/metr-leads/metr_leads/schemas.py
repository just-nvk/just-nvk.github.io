"""Что принимаем от формы и как объясняем ошибки — по-русски и для каждого поля отдельно."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field, ValidationError, ValidationInfo, field_validator

from .domain import normalize_phone

FIELD_ERRORS = {
    "name": "Как к вам обращаться? Нужно от 2 до 80 символов",
    "phone": "Проверьте номер: нужен российский, +7 и 10 цифр",
    "service": "Выберите вид работ",
    "area": "Площадь — целое число от 5 до 2000 м²",
    "comment": "Комментарий — не длиннее 1000 символов",
    "consent": "Нужно согласие на обработку персональных данных",
}
OTHER_ERROR = "Проверьте это поле"


class LeadIn(BaseModel):
    """Заявка с сайта. Лишние поля игнорируются, пробелы по краям обрезаются."""

    model_config = ConfigDict(str_strip_whitespace=True, extra="ignore")

    name: str = Field(min_length=2, max_length=80)
    phone: str
    service: str
    area: int | None = Field(default=None, ge=5, le=2000)
    comment: str = Field(default="", max_length=1000)
    consent: bool
    # Ловушка для ботов: поле спрятано от людей, а боты заполняют всё подряд.
    website: str = Field(default="", max_length=200)
    # Ключ формы: повторная отправка той же формы не создаёт вторую заявку.
    request_id: str | None = Field(default=None, pattern=r"^[A-Za-z0-9_-]{8,64}$")
    page: str = Field(default="", max_length=300)
    utm_source: str = Field(default="", max_length=100)
    utm_medium: str = Field(default="", max_length=100)
    utm_campaign: str = Field(default="", max_length=100)

    @field_validator("phone")
    @classmethod
    def _phone(cls, v: str) -> str:
        return normalize_phone(v)

    @field_validator("service")
    @classmethod
    def _service(cls, v: str, info: ValidationInfo) -> str:
        services = (info.context or {}).get("services")
        if services is not None and v not in services:
            raise ValueError("unknown service")
        return v

    @field_validator("consent")
    @classmethod
    def _consent(cls, v: bool) -> bool:
        if not v:
            raise ValueError("consent required")
        return v

    @field_validator("area", mode="before")
    @classmethod
    def _area(cls, v: object) -> object:
        return None if v == "" else v  # пустое поле формы = площадь не указана

    @field_validator("request_id", mode="before")
    @classmethod
    def _request_id(cls, v: object) -> object:
        return None if v == "" else v


def human_errors(exc: ValidationError) -> dict[str, str]:
    """Ошибки pydantic → {поле: понятный текст}. Ошибка в служебном поле не ломает форму, но и не теряется."""
    out: dict[str, str] = {}
    for err in exc.errors():
        name = str(err["loc"][0]) if err["loc"] else "form"
        out.setdefault(name, FIELD_ERRORS.get(name, OTHER_ERROR))
    return out
