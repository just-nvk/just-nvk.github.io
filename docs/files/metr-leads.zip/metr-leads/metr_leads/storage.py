"""SQLite: заявки и очередь уведомлений. Один файл — легко копировать для резервной копии."""

from __future__ import annotations

import re
import sqlite3
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path

from .domain import STATUSES
from .schemas import LeadIn

SCHEMA = """
CREATE TABLE IF NOT EXISTS leads (
  id           INTEGER PRIMARY KEY,
  created_at   TEXT NOT NULL,
  name         TEXT NOT NULL,
  phone        TEXT NOT NULL,
  service      TEXT NOT NULL,
  area         INTEGER,
  comment      TEXT NOT NULL DEFAULT '',
  page         TEXT NOT NULL DEFAULT '',
  utm_source   TEXT NOT NULL DEFAULT '',
  utm_medium   TEXT NOT NULL DEFAULT '',
  utm_campaign TEXT NOT NULL DEFAULT '',
  status       TEXT NOT NULL DEFAULT 'new' CHECK (status IN ('new', 'in_work', 'done', 'spam')),
  repeat_of    INTEGER REFERENCES leads(id),
  request_id   TEXT UNIQUE
);
CREATE INDEX IF NOT EXISTS leads_phone ON leads (phone, created_at);
CREATE INDEX IF NOT EXISTS leads_status ON leads (status, id);

CREATE TABLE IF NOT EXISTS outbox (
  id          INTEGER PRIMARY KEY,
  lead_id     INTEGER NOT NULL REFERENCES leads(id),
  attempts    INTEGER NOT NULL DEFAULT 0,
  next_try_at TEXT NOT NULL,
  sent_at     TEXT,
  last_error  TEXT
);
CREATE INDEX IF NOT EXISTS outbox_due ON outbox (sent_at, next_try_at);
"""


def iso(moment: datetime) -> str:
    return moment.astimezone(UTC).isoformat(timespec="seconds")


def from_iso(text: str) -> datetime:
    return datetime.fromisoformat(text)


@dataclass(frozen=True)
class Lead:
    id: int
    created_at: datetime
    name: str
    phone: str
    service: str
    area: int | None
    comment: str
    page: str
    utm_source: str
    utm_medium: str
    utm_campaign: str
    status: str
    repeat_of: int | None
    request_id: str | None

    @classmethod
    def from_row(cls, row: sqlite3.Row) -> Lead:
        data = dict(row)
        data["created_at"] = from_iso(data["created_at"])
        return cls(**data)


@dataclass(frozen=True)
class Notification:
    id: int
    lead_id: int
    attempts: int


class Storage:
    def __init__(self, path: Path):
        self.path = path
        path.parent.mkdir(parents=True, exist_ok=True)
        with self._conn() as conn:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.executescript(SCHEMA)

    @contextmanager
    def _conn(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(self.path, timeout=10, isolation_level=None)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        # Поиск по имени без учёта регистра: встроенный LOWER в SQLite не знает кириллицу.
        conn.create_function("py_lower", 1, lambda s: s.lower() if isinstance(s, str) else s, deterministic=True)
        try:
            yield conn
        finally:
            conn.close()

    # ---------- заявки ----------

    def add_lead(self, data: LeadIn, now: datetime, repeat_hours: int, spam: bool = False) -> tuple[Lead, bool]:
        """Сохраняет заявку и ставит уведомление в очередь — в одной транзакции.

        Возвращает (заявка, создана ли новая). Повторная отправка той же формы (тот же request_id)
        возвращает уже сохранённую заявку. Заявка с номера, который уже писал за repeat_hours,
        помечается как повторная и ссылается на первую.
        """
        with self._conn() as conn:
            conn.execute("BEGIN IMMEDIATE")
            try:
                if data.request_id:
                    row = conn.execute("SELECT * FROM leads WHERE request_id = ?", (data.request_id,)).fetchone()
                    if row:
                        conn.execute("COMMIT")
                        return Lead.from_row(row), False
                repeat_of = None
                if not spam:
                    since = iso(now - timedelta(hours=repeat_hours))
                    row = conn.execute(
                        "SELECT COALESCE(repeat_of, id) FROM leads WHERE phone = ? AND created_at >= ? "
                        "AND status != 'spam' ORDER BY id DESC LIMIT 1",
                        (data.phone, since),
                    ).fetchone()
                    repeat_of = row[0] if row else None
                cur = conn.execute(
                    "INSERT INTO leads (created_at, name, phone, service, area, comment, page, utm_source, "
                    "utm_medium, utm_campaign, status, repeat_of, request_id) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (iso(now), data.name, data.phone, data.service, data.area, data.comment, data.page,
                     data.utm_source, data.utm_medium, data.utm_campaign, "spam" if spam else "new",
                     repeat_of, data.request_id),
                )
                lead_id = cur.lastrowid
                if not spam:
                    conn.execute("INSERT INTO outbox (lead_id, next_try_at) VALUES (?, ?)", (lead_id, iso(now)))
                row = conn.execute("SELECT * FROM leads WHERE id = ?", (lead_id,)).fetchone()
                conn.execute("COMMIT")
            except BaseException:
                conn.execute("ROLLBACK")
                raise
        return Lead.from_row(row), True

    def by_request_id(self, request_id: str) -> Lead | None:
        with self._conn() as conn:
            row = conn.execute("SELECT * FROM leads WHERE request_id = ?", (request_id,)).fetchone()
        return Lead.from_row(row) if row else None

    def get(self, lead_id: int) -> Lead | None:
        with self._conn() as conn:
            row = conn.execute("SELECT * FROM leads WHERE id = ?", (lead_id,)).fetchone()
        return Lead.from_row(row) if row else None

    def list(self, status: str | None = None, q: str = "", limit: int = 100, offset: int = 0,
             hide_spam: bool = False) -> list[Lead]:
        where, args = self._filters(status, q, hide_spam)
        with self._conn() as conn:
            rows = conn.execute(
                f"SELECT * FROM leads {where} ORDER BY id DESC LIMIT ? OFFSET ?", (*args, limit, offset)
            ).fetchall()
        return [Lead.from_row(r) for r in rows]

    def count(self, status: str | None = None, q: str = "", hide_spam: bool = False) -> int:
        where, args = self._filters(status, q, hide_spam)
        with self._conn() as conn:
            return conn.execute(f"SELECT COUNT(*) FROM leads {where}", args).fetchone()[0]

    def counts(self) -> dict[str, int]:
        with self._conn() as conn:
            rows = conn.execute("SELECT status, COUNT(*) FROM leads GROUP BY status").fetchall()
        out = dict.fromkeys(STATUSES, 0)
        out.update({r[0]: r[1] for r in rows})
        return out

    @staticmethod
    def _filters(status: str | None, q: str, hide_spam: bool = False) -> tuple[str, tuple]:
        parts: list[str] = []
        args: list = []
        if status:
            parts.append("status = ?")
            args.append(status)
        elif hide_spam:
            parts.append("status != 'spam'")
        q = q.strip()
        if q:
            digits = re.sub(r"[\s()+\-]", "", q)
            if digits.isdigit() and len(digits) >= 3:  # похоже на номер — ищем по телефону
                parts.append("(phone LIKE ? OR phone LIKE ?)")
                # «8 903 555» — начало номера: восьмёрка вместо +7.
                start = "+7" + digits[1:] if digits[0] == "8" else "+" + digits
                args += [f"%{digits}%", f"{start}%"]
            else:
                parts.append("(py_lower(name) LIKE ? OR py_lower(comment) LIKE ?)")
                like = f"%{q.lower()}%"
                args += [like, like]
        return ("WHERE " + " AND ".join(parts)) if parts else "", tuple(args)

    def set_status(self, lead_id: int, status: str) -> Lead | None:
        if status not in STATUSES:
            raise ValueError(f"unknown status {status}")
        with self._conn() as conn:
            conn.execute("UPDATE leads SET status = ? WHERE id = ?", (status, lead_id))
        return self.get(lead_id)

    # ---------- очередь уведомлений ----------

    def due_notifications(self, now: datetime, limit: int = 20) -> list[Notification]:
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT id, lead_id, attempts FROM outbox WHERE sent_at IS NULL AND next_try_at <= ? "
                "ORDER BY id LIMIT ?",
                (iso(now), limit),
            ).fetchall()
        return [Notification(**dict(r)) for r in rows]

    def mark_sent(self, notification_id: int, now: datetime) -> None:
        with self._conn() as conn:
            conn.execute(
                "UPDATE outbox SET sent_at = ?, attempts = attempts + 1, last_error = NULL WHERE id = ?",
                (iso(now), notification_id),
            )

    def schedule_retry(self, notification_id: int, next_try: datetime, error: str) -> None:
        with self._conn() as conn:
            conn.execute(
                "UPDATE outbox SET attempts = attempts + 1, next_try_at = ?, last_error = ? WHERE id = ?",
                (iso(next_try), error[:500], notification_id),
            )

    def outbox_stats(self, now: datetime) -> dict:
        with self._conn() as conn:
            pending, oldest, error = conn.execute(
                "SELECT COUNT(*), MIN(l.created_at), "
                "(SELECT last_error FROM outbox WHERE sent_at IS NULL AND last_error IS NOT NULL "
                "ORDER BY id DESC LIMIT 1) "
                "FROM outbox o JOIN leads l ON l.id = o.lead_id WHERE o.sent_at IS NULL"
            ).fetchone()
        waiting = int((now - from_iso(oldest)).total_seconds() // 60) if oldest else 0
        return {"pending": pending, "oldest_pending_minutes": waiting, "last_error": error}

    def delivery(self, lead_ids: list[int]) -> dict[int, str]:
        """Статус уведомления для админки: sent — доставлено, pending — ждёт отправки."""
        if not lead_ids:
            return {}
        marks = ",".join("?" * len(lead_ids))
        with self._conn() as conn:
            rows = conn.execute(
                f"SELECT lead_id, MAX(sent_at IS NOT NULL) FROM outbox WHERE lead_id IN ({marks}) GROUP BY lead_id",
                lead_ids,
            ).fetchall()
        return {r[0]: "sent" if r[1] else "pending" for r in rows}
