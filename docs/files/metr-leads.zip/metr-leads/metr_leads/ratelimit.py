"""Ограничение частоты: не больше N заявок с одного IP за окно. Хранится в памяти процесса — IP в базу не пишем."""

from __future__ import annotations

import math
from collections import deque
from collections.abc import Callable
from datetime import datetime


class RateLimiter:
    def __init__(self, limit: int, window_seconds: int, clock: Callable[[], datetime]):
        self.limit = limit
        self.window = window_seconds
        self.clock = clock
        self._hits: dict[str, deque[float]] = {}

    def hit(self, key: str) -> int:
        """Учитывает попытку. Возвращает 0, если можно, иначе — через сколько секунд можно снова."""
        now = self.clock().timestamp()
        if len(self._hits) > 10_000:
            self._forget_old(now)
        hits = self._hits.setdefault(key, deque())
        while hits and hits[0] <= now - self.window:
            hits.popleft()
        if len(hits) >= self.limit:
            return max(1, math.ceil(hits[0] + self.window - now))
        hits.append(now)
        return 0

    def _forget_old(self, now: float) -> None:
        for key in [k for k, v in self._hits.items() if not v or v[-1] <= now - self.window]:
            del self._hits[key]
