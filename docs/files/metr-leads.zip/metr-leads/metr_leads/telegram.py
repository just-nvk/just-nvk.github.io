"""Уведомление менеджерам в Telegram: текст сообщения и отправка через Bot API."""

from __future__ import annotations

from datetime import datetime
from html import escape
from urllib.parse import urlsplit

import httpx

from .config import Company
from .domain import format_phone, human_time, utm_line
from .storage import Lead


def short_page(url: str) -> str:
    """https://metr.example/remont?utm_source=… → metr.example/remont"""
    if not url:
        return ""
    parts = urlsplit(url if "//" in url else "//" + url)
    return (parts.netloc + parts.path).rstrip("/") or url


def lead_message(lead: Lead, company: Company, now: datetime, first: Lead | None = None,
                 admin_url: str = "") -> tuple[str, dict | None]:
    """Текст (HTML-разметка Telegram) и кнопка. Всё, что ввёл посетитель, экранируется."""
    service = company.services.get(lead.service, lead.service)
    title = "Повторная заявка" if lead.repeat_of else "Новая заявка"
    head = escape(service) + (f" · {lead.area} м²" if lead.area else "")
    lines = [f"<b>{title} №{lead.id}</b>", head]
    if first:
        lines.append(f"Первая — №{first.id}, {human_time(first.created_at, now, company.timezone)}")
    lines += ["", f"Имя: {escape(lead.name)}", f"Телефон: {format_phone(lead.phone)}"]
    if lead.comment:
        lines.append(f"Комментарий: {escape(lead.comment)}")
    source = " · ".join(p for p in (short_page(lead.page), utm_line(lead.utm_source, lead.utm_medium,
                                                                     lead.utm_campaign)) if p)
    lines.append("")
    if source:
        lines.append(f"Откуда: {escape(source)}")
    lines.append(f"Пришла {human_time(lead.created_at, now, company.timezone)}")
    markup = None
    if admin_url:
        markup = {"inline_keyboard": [[{"text": "Открыть в админке", "url": f"{admin_url}#lead-{lead.id}"}]]}
    return "\n".join(lines), markup


class TelegramError(Exception):
    def __init__(self, message: str, *, retry_after: int | None = None, permanent: bool = False):
        super().__init__(message)
        self.retry_after = retry_after
        self.permanent = permanent


class Telegram:
    def __init__(self, token: str, chat_id: str, client: httpx.AsyncClient):
        self.token = token
        self.chat_id = chat_id
        self.client = client

    async def send(self, text: str, markup: dict | None = None) -> None:
        payload: dict = {"chat_id": self.chat_id, "text": text, "parse_mode": "HTML",
                         "link_preview_options": {"is_disabled": True}}
        if markup:
            payload["reply_markup"] = markup
        try:
            r = await self.client.post(f"/bot{self.token}/sendMessage", json=payload)
        except httpx.HTTPError as e:
            raise TelegramError(f"сеть: {type(e).__name__}") from e
        try:
            data = r.json()
        except ValueError:
            data = {}
        if r.status_code == 200 and data.get("ok"):
            return
        description = data.get("description") or f"HTTP {r.status_code}"
        if r.status_code == 429:
            retry = int((data.get("parameters") or {}).get("retry_after") or 30)
            raise TelegramError(description, retry_after=retry)
        # 400 — неверный чат, 401 — неверный токен, 403 — бота убрали из чата: сами не пройдут.
        raise TelegramError(description, permanent=400 <= r.status_code < 500)
