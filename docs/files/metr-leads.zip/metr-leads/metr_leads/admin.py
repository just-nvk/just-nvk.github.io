"""Админка для менеджеров: список заявок, статусы, поиск, выгрузка в Excel. Вход по логину и паролю из .env."""

from __future__ import annotations

import asyncio
import csv
import io
import secrets
from typing import Annotated, Literal
from urllib.parse import urlencode, urlsplit

from fastapi import APIRouter, Depends, Form, HTTPException, Query, Request
from fastapi.responses import RedirectResponse, Response
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from pydantic import BaseModel

from .domain import STATUSES, csv_safe, format_phone, format_phone_csv, human_time, utm_line
from .storage import Lead
from .telegram import short_page

router = APIRouter()
basic = HTTPBasic(auto_error=False, realm="Metr leads")
PAGE_SIZE = 50
AUTH_HEADER = {"WWW-Authenticate": 'Basic realm="Metr leads", charset="UTF-8"'}

StatusCode = Literal["new", "in_work", "done", "spam"]
TABS = {"new": "Новые", "in_work": "В работе", "done": "Готово", "spam": "Спам"}


def require_admin(request: Request, credentials: Annotated[HTTPBasicCredentials | None, Depends(basic)]) -> str:
    settings = request.app.state.settings
    if not settings.admin_enabled:
        raise HTTPException(503, "Админка выключена: задайте ADMIN_PASSWORD в .env")
    if credentials is not None:
        # compare_digest сравнивает за одинаковое время — пароль нельзя подобрать по скорости ответа.
        user_ok = secrets.compare_digest(credentials.username.encode(), settings.admin_user.encode())
        password_ok = secrets.compare_digest(credentials.password.encode(), settings.admin_password.encode())
        if user_ok and password_ok:
            return credentials.username
    raise HTTPException(401, "Нужен логин и пароль", headers=AUTH_HEADER)


Admin = Annotated[str, Depends(require_admin)]


def same_origin(request: Request) -> bool:
    """Защита от подделки запроса (CSRF): менять статус можно только со страницы самой админки."""
    source = request.headers.get("origin") or request.headers.get("referer") or ""
    host = request.headers.get("host", "")
    return bool(source) and urlsplit(source).netloc == host


def lead_json(lead: Lead, request: Request) -> dict:
    company = request.app.state.company
    return {
        "id": lead.id,
        "created_at": lead.created_at.isoformat(),
        "name": lead.name,
        "phone": lead.phone,
        "service": lead.service,
        "service_name": company.services.get(lead.service, lead.service),
        "area": lead.area,
        "comment": lead.comment,
        "page": lead.page,
        "utm_source": lead.utm_source,
        "utm_medium": lead.utm_medium,
        "utm_campaign": lead.utm_campaign,
        "status": lead.status,
        "repeat_of": lead.repeat_of,
    }


@router.get("/admin", include_in_schema=False)
async def admin_page(request: Request, _: Admin, status: StatusCode | None = None,
                     q: Annotated[str, Query(max_length=100)] = "", page: Annotated[int, Query(ge=1)] = 1):
    state = request.app.state
    storage, company = state.storage, state.company
    # «Все» — без спама: его видно только на своей вкладке.
    leads = await asyncio.to_thread(storage.list, status, q, PAGE_SIZE, (page - 1) * PAGE_SIZE, True)
    total = await asyncio.to_thread(storage.count, status, q, True)
    counts = await asyncio.to_thread(storage.counts)
    delivery = await asyncio.to_thread(storage.delivery, [lead.id for lead in leads])
    now = state.clock()

    def link(**params) -> str:
        merged = {"status": status, "q": q, **params}
        query = urlencode({k: v for k, v in merged.items() if v not in (None, "", 1)})
        return "/admin" + ("?" + query if query else "")

    rows = [{
        "lead": lead,
        "when": human_time(lead.created_at, now, company.timezone),
        "phone": format_phone(lead.phone),
        "service": company.services.get(lead.service, lead.service),
        "page": short_page(lead.page),
        "utm": utm_line(lead.utm_source, lead.utm_medium, lead.utm_campaign),
        "delivery": delivery.get(lead.id),
    } for lead in leads]
    tabs = [{"code": None, "title": "Все", "count": sum(counts.values()) - counts["spam"]}] + [
        {"code": code, "title": title, "count": counts[code]} for code, title in TABS.items()]
    csv_query = urlencode({k: v for k, v in {"status": status, "q": q}.items() if v})
    return state.templates.TemplateResponse(request, "admin.html", {
        "rows": rows, "tabs": tabs, "status": status, "q": q, "total": total, "statuses": STATUSES,
        "page": page, "pages": max(1, -(-total // PAGE_SIZE)), "link": link,
        "csv_url": "/admin/leads.csv" + ("?" + csv_query if csv_query else ""),
        "back": link(page=page),
    })


@router.post("/admin/leads/{lead_id}/status", include_in_schema=False)
async def admin_set_status(request: Request, _: Admin, lead_id: int, status: Annotated[StatusCode, Form()],
                           back: Annotated[str, Form()] = "/admin"):
    if not same_origin(request):
        raise HTTPException(403, "Запрос пришёл не со страницы админки")
    lead = await asyncio.to_thread(request.app.state.storage.set_status, lead_id, status)
    if lead is None:
        raise HTTPException(404, "Заявка не найдена")
    if not back.startswith("/admin"):
        back = "/admin"
    return RedirectResponse(f"{back}#lead-{lead_id}", status_code=303)


@router.get("/admin/leads.csv", tags=["Админка"], summary="Выгрузка заявок для Excel")
async def export_csv(request: Request, _: Admin, status: StatusCode | None = None,
                     q: Annotated[str, Query(max_length=100)] = "") -> Response:
    """CSV открывается в Excel двойным кликом: UTF-8 с BOM, разделитель — точка с запятой."""
    state = request.app.state
    company = state.company
    leads = await asyncio.to_thread(state.storage.list, status, q, 100_000, 0, True)
    out = io.StringIO()
    writer = csv.writer(out, delimiter=";", lineterminator="\r\n")
    writer.writerow(["№", "Дата", "Время", "Имя", "Телефон", "Вид работ", "Площадь, м²", "Комментарий",
                     "Статус", "Повторная к №", "Страница", "utm_source", "utm_medium", "utm_campaign"])
    for lead in leads:
        local = lead.created_at.astimezone(company.timezone)
        writer.writerow([csv_safe(v) for v in (
            lead.id, local.strftime("%d.%m.%Y"), local.strftime("%H:%M"), lead.name, format_phone_csv(lead.phone),
            company.services.get(lead.service, lead.service), lead.area or "", lead.comment,
            STATUSES[lead.status], lead.repeat_of or "", lead.page, lead.utm_source, lead.utm_medium,
            lead.utm_campaign)])
    filename = f"leads-{state.clock().astimezone(company.timezone):%Y-%m-%d}.csv"
    return Response(("\ufeff" + out.getvalue()).encode("utf-8"), media_type="text/csv; charset=utf-8",
                    headers={"Content-Disposition": f'attachment; filename="{filename}"'})


class StatusIn(BaseModel):
    status: StatusCode


@router.get("/api/leads", tags=["Админка"], summary="Список заявок")
async def api_list(request: Request, _: Admin, status: StatusCode | None = None,
                   q: Annotated[str, Query(max_length=100)] = "",
                   limit: Annotated[int, Query(ge=1, le=500)] = 50, offset: Annotated[int, Query(ge=0)] = 0) -> dict:
    """Для CRM и отчётов. Поиск `q` — по имени и комментарию или по цифрам телефона."""
    storage = request.app.state.storage
    leads = await asyncio.to_thread(storage.list, status, q, limit, offset)
    total = await asyncio.to_thread(storage.count, status, q)
    return {"total": total, "items": [lead_json(lead, request) for lead in leads]}


@router.patch("/api/leads/{lead_id}", tags=["Админка"], summary="Сменить статус заявки")
async def api_set_status(request: Request, _: Admin, lead_id: int, body: StatusIn) -> dict:
    lead = await asyncio.to_thread(request.app.state.storage.set_status, lead_id, body.status)
    if lead is None:
        raise HTTPException(404, "Заявка не найдена")
    return lead_json(lead, request)
