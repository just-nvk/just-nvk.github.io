"""Запуск: python -m metr_leads"""

import logging
import os

import uvicorn

from .app import create_app
from .config import Settings


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    settings = Settings.from_env()
    if not settings.admin_enabled:
        logging.warning("ADMIN_PASSWORD не задан — админка выключена")
    host = os.environ.get("HOST", "127.0.0.1")
    port = int(os.environ.get("PORT", "8000"))
    # Адрес посетителя за nginx берём сами (TRUST_PROXY), поэтому встроенную обработку заголовков выключаем.
    uvicorn.run(create_app(settings), host=host, port=port, proxy_headers=False, access_log=False)


if __name__ == "__main__":
    main()
