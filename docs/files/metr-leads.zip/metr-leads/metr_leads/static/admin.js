// Статус меняется сразу при выборе — без кнопки «Сохранить». Без JavaScript кнопка видна.
document.querySelectorAll("[data-autosubmit]").forEach((select) => {
  select.addEventListener("change", () => select.form.requestSubmit());
});