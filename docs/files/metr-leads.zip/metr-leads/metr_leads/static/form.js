// Форма заявки. Работает и без этого скрипта (обычная отправка), а с ним — без перезагрузки страницы,
// с ошибками под полями и защитой от двойной отправки. Подключается на любой сайт одной строкой.
(() => {
  const UTM = ["utm_source", "utm_medium", "utm_campaign"];
  const UTM_KEY = "metr-leads-utm";
  const NETWORK = "Нет связи с сервером. Проверьте интернет и нажмите ещё раз.";
  const FAILED = "Не получилось отправить заявку. Попробуйте ещё раз или позвоните нам.";

  // Метки рекламы запоминаем с первой страницы визита: человек мог походить по сайту перед заявкой.
  const params = new URLSearchParams(location.search);
  try {
    if (UTM.some((k) => params.get(k))) {
      sessionStorage.setItem(UTM_KEY, JSON.stringify(Object.fromEntries(UTM.map((k) => [k, params.get(k) || ""]))));
    }
  } catch (e) { /* приватный режим: просто без меток */ }
  const savedUtm = () => {
    try { return JSON.parse(sessionStorage.getItem(UTM_KEY)) || {}; } catch (e) { return {}; }
  };

  const randomId = () => (crypto.randomUUID ? crypto.randomUUID() :
    Array.from(crypto.getRandomValues(new Uint8Array(16)), (b) => b.toString(16).padStart(2, "0")).join(""));

  document.querySelectorAll("[data-lead-form]").forEach((form) => {
    const button = form.querySelector("[type=submit]");
    const label = button.textContent;
    const general = form.querySelector("[data-form-error]");
    let requestId = form.elements.request_id;
    if (!requestId) {
      requestId = Object.assign(document.createElement("input"), { type: "hidden", name: "request_id" });
      form.append(requestId);
    }
    if (!requestId.value) requestId.value = randomId();

    const holderOf = (name) => form.querySelector(`[data-field="${name}"]`);

    const clearError = (name) => {
      const holder = holderOf(name);
      if (!holder) return;
      holder.classList.remove("has-error");
      holder.querySelector(".field-error")?.remove();
      holder.querySelectorAll("[aria-invalid]").forEach((el) => el.removeAttribute("aria-invalid"));
    };

    const showErrors = (errors) => {
      let first = null;
      const unplaced = [];
      for (const [name, text] of Object.entries(errors)) {
        const holder = holderOf(name);
        if (!holder) { unplaced.push(text); continue; }
        holder.classList.add("has-error");
        const note = Object.assign(document.createElement("p"), { className: "field-error", textContent: text });
        note.id = `err-${name}`;
        holder.append(note);
        holder.querySelectorAll("input, textarea, select").forEach((el) => {
          el.setAttribute("aria-invalid", "true");
          el.setAttribute("aria-describedby", note.id);
        });
        first = first || holder.querySelector("input, textarea, select");
      }
      if (unplaced.length) showGeneral(unplaced.join(". "));
      first?.focus();
    };

    const showGeneral = (text) => {
      if (!general) { alert(text); return; }
      general.textContent = text;
      general.hidden = false;
    };

    form.addEventListener("input", (e) => {
      const holder = e.target.closest("[data-field]");
      if (holder) clearError(holder.dataset.field);
    });

    const done = (message, data) => {
      const body = form.closest("[data-form-body]") || form;
      const box = document.createElement("div");
      box.className = "form-done";
      box.setAttribute("role", "status");
      box.innerHTML = '<div class="done-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M5 12.5l4.2 4.2L19 7" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg></div><h2></h2><p></p><dl></dl>';
      box.querySelector("h2").textContent = data.name?.trim() ? `Спасибо, ${data.name.trim()}!` : "Спасибо!";
      box.querySelector("p").textContent = message;
      const service = form.querySelector(`[name=service][value="${data.service}"]`)?.closest("label")?.textContent.trim();
      const rows = [["Имя", data.name], ["Телефон", data.phone], ["Что нужно", service && (data.area ? `${service} · ${data.area} м²` : service)]];
      for (const [term, value] of rows) {
        if (!value) continue;
        const dt = Object.assign(document.createElement("dt"), { textContent: term });
        const dd = Object.assign(document.createElement("dd"), { textContent: value });
        box.querySelector("dl").append(dt, dd);
      }
      body.replaceChildren(box);
      box.focus?.();
    };

    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      if (button.disabled) return;
      form.querySelectorAll("[data-field]").forEach((h) => clearError(h.dataset.field));
      if (general) general.hidden = true;

      const fields = new FormData(form);
      const data = Object.fromEntries(fields.entries());
      data.consent = fields.has("consent");
      Object.assign(data, savedUtm(), { page: location.href });

      button.disabled = true;
      button.textContent = "Отправляем…";
      try {
        const response = await fetch(form.action, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data),
        });
        const answer = await response.json().catch(() => ({}));
        if (response.ok) { done(answer.message || "Заявка отправлена.", data); return; }
        if (response.status === 422 && answer.errors) showErrors(answer.errors);
        else showGeneral(answer.message || FAILED);
      } catch (err) {
        showGeneral(NETWORK); // request_id тот же: повторная отправка не создаст вторую заявку
      }
      button.disabled = false;
      button.textContent = label;
    });
  });
})();