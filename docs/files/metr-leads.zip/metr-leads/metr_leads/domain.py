"""Правила без FastAPI и базы: телефоны, даты, тексты для людей. Чистые функции — их легко тестировать."""

from __future__ import annotations

import re
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

PHONE_ERROR = "Проверьте номер: нужен российский, +7 и 10 цифр"
# Первая цифра номера без кода страны: 3, 4, 8 — городские и бесплатные, 9 — мобильные.
_NATIONAL_FIRST = "3489"

STATUSES = {"new": "Новая", "in_work": "В работе", "done": "Готово", "spam": "Спам"}

MONTHS = ["января", "февраля", "марта", "апреля", "мая", "июня",
          "июля", "августа", "сентября", "октября", "ноября", "декабря"]


def normalize_phone(raw: str) -> str:
    """Приводит номер к виду +79991234567. Понимает 8 (999) 123-45-67, +7 999 123 45 67, 9991234567."""
    text = raw.strip()
    if re.search(r"[^\d\s()+\-.]", text):
        raise ValueError(PHONE_ERROR)
    digits = re.sub(r"\D", "", text)
    if len(digits) == 11 and digits[0] in "78":
        if text.startswith("+") and digits[0] != "7":
            raise ValueError(PHONE_ERROR)  # +8… — не российский формат
        digits = digits[1:]
    elif len(digits) != 10 or text.startswith("+"):
        raise ValueError(PHONE_ERROR)
    # Кодов 89x нет: «8 916 123 45 6» — это мобильный, в котором не хватает цифры.
    if digits[0] not in _NATIONAL_FIRST or digits.startswith("89"):
        raise ValueError(PHONE_ERROR)
    return "+7" + digits


def format_phone(phone: str) -> str:
    """+79991234567 → +7 999 123-45-67."""
    d = phone[2:]
    return f"+7 {d[0:3]} {d[3:6]}-{d[6:8]}-{d[8:10]}"


def format_phone_csv(phone: str) -> str:
    """+79991234567 → 8 999 123-45-67: с плюса в начале Excel начал бы формулу."""
    return "8" + format_phone(phone)[2:]


def human_time(moment: datetime, now: datetime, tz: ZoneInfo) -> str:
    """«сегодня в 14:05», «вчера в 09:30» или «2 ноября в 14:05» — в часовом поясе компании."""
    m, n = moment.astimezone(tz), now.astimezone(tz)
    hm = m.strftime("%H:%M")
    if m.date() == n.date():
        return f"сегодня в {hm}"
    if m.date() == (n - timedelta(days=1)).date():
        return f"вчера в {hm}"
    year = f" {m.year}" if m.year != n.year else ""
    return f"{m.day} {MONTHS[m.month - 1]}{year} в {hm}"


def utm_line(source: str, medium: str, campaign: str) -> str:
    return " · ".join(p for p in (source, medium, campaign) if p)


_CSV_DANGEROUS = ("=", "+", "-", "@", "\t", "\r")


def csv_safe(value: object) -> str:
    """Защита от формул в Excel: текст, который начинается с = + - @, Excel выполнил бы как формулу."""
    text = "" if value is None else str(value)
    return "'" + text if text.startswith(_CSV_DANGEROUS) else text
