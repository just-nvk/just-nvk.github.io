"""Очередь уведомлений. Заявка уже в базе — уведомление уходит следом и не теряется, даже если Telegram лежит."""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Callable
from datetime import datetime, timedelta

from .config import Company
from .storage import Storage
from .telegram import Telegram, TelegramError, lead_message

log = logging.getLogger("metr_leads.outbox")

# Пауза перед следующей попыткой: 30 с, 1 мин, 2 мин, 5 мин, 10 мин, 30 мин, дальше — раз в час.
BACKOFF = [30, 60, 120, 300, 600, 1800, 3600]


class OutboxWorker:
    def __init__(self, storage: Storage, telegram: Telegram, company: Company, clock: Callable[[], datetime],
                 admin_url: str = "", interval: float = 5.0):
        self.storage = storage
        self.telegram = telegram
        self.company = company
        self.clock = clock
        self.admin_url = admin_url
        self.interval = interval
        self._wake = asyncio.Event()

    def wake(self) -> None:
        """Новая заявка: не ждать следующего круга, отправить сразу."""
        self._wake.set()

    async def run_once(self) -> int:
        """Отправляет всё, чему пора. Возвращает, сколько уведомлений ушло."""
        now = self.clock()
        due = await asyncio.to_thread(self.storage.due_notifications, now)
        sent = 0
        for item in due:
            lead = await asyncio.to_thread(self.storage.get, item.lead_id)
            first = await asyncio.to_thread(self.storage.get, lead.repeat_of) if lead.repeat_of else None
            text, markup = lead_message(lead, self.company, now, first, self.admin_url)
            try:
                await self.telegram.send(text, markup)
            except TelegramError as e:
                if e.retry_after:
                    delay = e.retry_after
                elif e.permanent:
                    delay = BACKOFF[-1]
                else:
                    delay = BACKOFF[min(item.attempts, len(BACKOFF) - 1)]
                await asyncio.to_thread(self.storage.schedule_retry, item.id, now + timedelta(seconds=delay), str(e))
                log.warning("Заявка №%s: уведомление не ушло (%s), повтор через %s с", lead.id, e, delay)
                if e.retry_after or e.permanent:
                    break  # лимит Telegram или ошибка настроек: остальные тоже не пройдут
                continue
            await asyncio.to_thread(self.storage.mark_sent, item.id, self.clock())
            sent += 1
        return sent

    async def run_forever(self) -> None:
        while True:
            self._wake.clear()
            try:
                await self.run_once()
            except Exception:
                log.exception("Ошибка в очереди уведомлений")
            try:
                await asyncio.wait_for(self._wake.wait(), self.interval)
            except TimeoutError:
                pass
