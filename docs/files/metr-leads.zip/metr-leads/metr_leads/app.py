"""HTTP-сервис: приём заявок с сайта, демо-страница с формой и проверка здоровья."""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import uuid
from collections.abc import Callable
from contextlib import asynccontextmanager
from datetime import UTC, datetime
from pathlib import Path
from urllib.parse import parse_qsl

import httpx
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, RedirectResponse, Response
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import ValidationError

from . import admin
from .config import Company, Settings
from .outbox import OutboxWorker
from .ratelimit import RateLimiter
from .schemas import LeadIn, human_errors
from .storage import Storage
from .telegram import Telegram

log = logging.getLogger("metr_leads")

HERE = Path(__file__).parent
MAX_BODY = 20_000  # байт: настоящая заявка занимает около килобайта
JSON_TYPES = {"application/json"}
FORM_TYPES = {"application/x-www-form-urlencoded"}

TOO_MANY = "Слишком много заявок подряд. Попробуйте через {minutes} мин или позвоните нам."
BAD_FORM = "Проверьте поля формы"


class BodyTooLarge(Exception):
    pass


async def read_body(request: Request, limit: int) -> bytes:
    """Читает тело запроса, но не больше limit байт: огромный запрос обрывается, а не грузит память."""
    length = request.headers.get("content-length", "")
    if length.isdigit() and int(length) > limit:
        raise BodyTooLarge
    body = bytearray()
    async for chunk in request.stream():
        body += chunk
        if len(body) > limit:
            raise BodyTooLarge
    return bytes(body)


def client_ip(request: Request, trust_proxy: bool) -> str:
    """IP посетителя. За nginx настоящий адрес — в X-Real-IP. Без прокси заголовкам не верим: их легко подделать."""
    if trust_proxy:
        real = request.headers.get("x-real-ip", "").strip()
        if real:
            return real
        forwarded = request.headers.get("x-forwarded-for", "")
        if forwarded:
            return forwarded.split(",")[-1].strip()
    return request.client.host if request.client else "unknown"


def create_app(settings: Settings | None = None, *, clock: Callable[[], datetime] | None = None,
               telegram_transport: httpx.AsyncBaseTransport | None = None, start_worker: bool = True) -> FastAPI:
    settings = settings or Settings.from_env()
    clock = clock or (lambda: datetime.now(UTC))
    company = Company.load(settings.company_path)
    storage = Storage(settings.db_path)
    limiter = RateLimiter(settings.rate_limit, settings.rate_window, clock)
    templates = Jinja2Templates(directory=HERE / "templates")
    templates.env.globals["company"] = company

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        client = task = None
        if settings.telegram_enabled:
            client = httpx.AsyncClient(base_url="https://api.telegram.org", timeout=15, transport=telegram_transport)
            telegram = Telegram(settings.telegram_token, settings.telegram_chat_id, client)
            app.state.worker = OutboxWorker(storage, telegram, company, clock, settings.admin_url)
            if start_worker:
                task = asyncio.create_task(app.state.worker.run_forever())
        else:
            log.warning("Telegram не настроен: заявки сохраняются, уведомления ждут в очереди")
        yield
        if task:
            task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await task
        if client:
            await client.aclose()

    app = FastAPI(
        title=f"{company.name} · заявки",
        description="Приём заявок с сайта, уведомления в Telegram, админка для менеджеров.",
        version="1.0.0",
        lifespan=lifespan,
        docs_url="/docs" if settings.docs else None,
        redoc_url=None,
        openapi_url="/openapi.json" if settings.docs else None,
    )
    app.state.settings = settings
    app.state.company = company
    app.state.storage = storage
    app.state.limiter = limiter
    app.state.templates = templates
    app.state.clock = clock
    app.state.worker = None

    if settings.allowed_origins:
        # Форма на сайте компании отправляет заявку прямо в сервис. Другим сайтам браузер это запретит.
        app.add_middleware(CORSMiddleware, allow_origins=list(settings.allowed_origins),
                           allow_methods=["POST"], allow_headers=["Content-Type"], max_age=86400)

    app.mount("/static", StaticFiles(directory=HERE / "static"), name="static")

    def html_error(request: Request, status: int, title: str, message: str,
                   errors: dict[str, str] | None = None, headers: dict | None = None) -> Response:
        return templates.TemplateResponse(
            request, "error.html", {"title": title, "message": message, "errors": errors or {}},
            status_code=status, headers=headers)

    @app.post("/api/leads", tags=["Заявки"], summary="Принять заявку с сайта", status_code=201,
              responses={200: {"description": "Эта форма уже отправлена — вторая заявка не создана"},
                         303: {"description": "Обычная HTML-форма: переход на страницу «Спасибо»"},
                         413: {"description": "Слишком большой запрос"},
                         415: {"description": "Нужен JSON или обычная форма"},
                         422: {"description": "Ошибки в полях — по-русски, для каждого поля"},
                         429: {"description": "Слишком много заявок с одного адреса"}},
              openapi_extra={"requestBody": {"required": True, "content": {
                  "application/json": {"schema": LeadIn.model_json_schema(), "example": {
                      "name": "Анна", "phone": "8 (916) 123-45-67", "service": "turnkey", "area": 54,
                      "comment": "Двушка в новостройке, хотим начать в декабре", "consent": True}},
                  "application/x-www-form-urlencoded": {"schema": LeadIn.model_json_schema()}}}})
    async def create_lead(request: Request) -> Response:
        """Принимает JSON (форма с JavaScript) или обычную HTML-форму.

        Сначала заявка сохраняется в базу, потом уходит уведомление в Telegram: если Telegram недоступен,
        заявка не теряется. Номер заявки наружу не отдаём — по нему конкуренты считали бы ваши заявки.
        """
        content_type = request.headers.get("content-type", "").split(";")[0].strip().lower()
        is_form = content_type in FORM_TYPES
        if content_type not in JSON_TYPES and not is_form:
            return JSONResponse({"ok": False, "message": "Отправьте заявку как JSON или обычную форму"}, 415)
        try:
            body = await read_body(request, MAX_BODY)
        except BodyTooLarge:
            if is_form:
                return html_error(request, 413, "Слишком длинная заявка", "Сократите комментарий и отправьте ещё раз.")
            return JSONResponse({"ok": False, "message": "Слишком большой запрос"}, 413)

        try:
            if is_form:
                raw = dict(parse_qsl(body.decode("utf-8"), keep_blank_values=True))
                raw["consent"] = raw.get("consent", "") != ""  # галочка: есть в форме — значит, отмечена
            else:
                raw = json.loads(body or b"null")
                if not isinstance(raw, dict):
                    raise ValueError
        except (ValueError, UnicodeDecodeError):
            return JSONResponse({"ok": False, "message": "Не удалось прочитать заявку"}, 400)

        try:
            data = LeadIn.model_validate(raw, context={"services": company.services})
        except ValidationError as exc:
            errors = human_errors(exc)
            if is_form:
                return html_error(request, 422, "Проверьте заявку", BAD_FORM, errors)
            return JSONResponse({"ok": False, "message": BAD_FORM, "errors": errors}, 422)

        if not data.page:  # страница, с которой отправили форму, — для поля «Откуда»
            data.page = request.headers.get("referer", "")[:300]

        # Та же форма пришла второй раз (двойной клик, повтор после обрыва связи) — отвечаем как в первый.
        if data.request_id and await asyncio.to_thread(storage.by_request_id, data.request_id):
            return success(request, is_form, status=200)

        retry = limiter.hit(client_ip(request, settings.trust_proxy))
        if retry:
            message = TOO_MANY.format(minutes=max(1, round(retry / 60)))
            headers = {"Retry-After": str(retry)}
            if is_form:
                return html_error(request, 429, "Подождите немного", message, headers=headers)
            return JSONResponse({"ok": False, "message": message}, 429, headers=headers)

        spam = bool(data.website)  # невидимое поле заполнил бот
        lead, created = await asyncio.to_thread(storage.add_lead, data, clock(), settings.repeat_hours, spam)
        if created and not spam:
            log.info("Заявка №%s сохранена%s", lead.id, " (повторная)" if lead.repeat_of else "")
            if app.state.worker:
                app.state.worker.wake()
        # Боту отвечаем так же, как человеку: пусть не знает, что попался.
        return success(request, is_form, status=201 if created else 200)

    def success(request: Request, is_form: bool, status: int) -> Response:
        if is_form:
            return RedirectResponse(settings.thanks_url, status_code=303)
        return JSONResponse({"ok": True, "message": company.thanks}, status)

    @app.get("/", include_in_schema=False)
    async def landing(request: Request) -> Response:
        if not settings.demo_page:
            return JSONResponse({"service": app.title, "docs": "/docs" if settings.docs else None})
        return templates.TemplateResponse(request, "landing.html", {"request_id": uuid.uuid4().hex})

    @app.get("/thanks", include_in_schema=False)
    async def thanks(request: Request) -> Response:
        return templates.TemplateResponse(request, "thanks.html", {})

    @app.get("/health", tags=["Служебное"], summary="Проверка для мониторинга")
    async def health() -> dict:
        """`degraded` — уведомления не уходят в Telegram дольше 10 минут: проверьте заявки в админке."""
        stats = await asyncio.to_thread(storage.outbox_stats, clock())
        ok = settings.telegram_enabled and stats["oldest_pending_minutes"] < 10
        return {"status": "ok" if ok else "degraded", "telegram": settings.telegram_enabled, "outbox": stats}

    app.include_router(admin.router)
    return app
