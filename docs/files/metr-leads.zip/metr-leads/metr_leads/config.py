"""Настройки: секреты и адреса — в .env, данные компании (название, виды работ) — в company.toml."""

from __future__ import annotations

import os
import tomllib
from dataclasses import dataclass
from pathlib import Path
from zoneinfo import ZoneInfo

from dotenv import load_dotenv


@dataclass(frozen=True)
class Company:
    name: str
    tagline: str
    timezone: ZoneInfo
    services: dict[str, str]  # код → название: {"turnkey": "Ремонт под ключ"}
    thanks: str = "Заявка отправлена — скоро перезвоним."
    privacy_url: str = ""

    @classmethod
    def load(cls, path: Path) -> Company:
        data = tomllib.loads(path.read_text(encoding="utf-8"))
        services = data.get("services") or {}
        if not services:
            raise ValueError(f"{path}: добавьте хотя бы одну услугу в [services]")
        return cls(
            name=data["name"],
            tagline=data.get("tagline", ""),
            timezone=ZoneInfo(data.get("timezone", "Europe/Moscow")),
            services=dict(services),
            thanks=data.get("thanks") or cls.thanks,
            privacy_url=data.get("privacy_url", ""),
        )


def _bool(value: str | None, default: bool) -> bool:
    if value is None or value == "":
        return default
    return value.strip().lower() in {"1", "true", "yes", "on", "да"}


@dataclass(frozen=True)
class Settings:
    db_path: Path = Path("data/leads.db")
    company_path: Path = Path("company.toml")
    telegram_token: str = ""
    telegram_chat_id: str = ""
    admin_user: str = "admin"
    admin_password: str = ""
    # Публичный адрес админки (https://…/admin): для кнопки «Открыть в админке» в уведомлении.
    admin_url: str = ""
    # Сайты, с которых можно отправлять заявки из браузера (CORS).
    allowed_origins: tuple[str, ...] = ()
    rate_limit: int = 5  # заявок с одного IP…
    rate_window: int = 600  # …за столько секунд
    repeat_hours: int = 24  # заявка с того же номера за это время — повторная
    trust_proxy: bool = False  # сервис за nginx: IP клиента берём из X-Real-IP
    thanks_url: str = "/thanks"  # куда вернуть посетителя после отправки формы без JavaScript
    demo_page: bool = True  # показывать демо-страницу с формой на /
    docs: bool = True  # документация API на /docs

    @property
    def telegram_enabled(self) -> bool:
        return bool(self.telegram_token and self.telegram_chat_id)

    @property
    def admin_enabled(self) -> bool:
        return bool(self.admin_password)

    @classmethod
    def from_env(cls, env: dict[str, str] | None = None) -> Settings:
        if env is None:
            load_dotenv()
            env = dict(os.environ)
        origins = tuple(o.strip().rstrip("/") for o in env.get("ALLOWED_ORIGINS", "").split(",") if o.strip())
        return cls(
            db_path=Path(env.get("DB_PATH") or "data/leads.db"),
            company_path=Path(env.get("COMPANY_CONFIG") or "company.toml"),
            telegram_token=env.get("TELEGRAM_BOT_TOKEN", ""),
            telegram_chat_id=env.get("TELEGRAM_CHAT_ID", ""),
            admin_user=env.get("ADMIN_USER") or "admin",
            admin_password=env.get("ADMIN_PASSWORD", ""),
            admin_url=env.get("ADMIN_URL", "").rstrip("/"),
            allowed_origins=origins,
            rate_limit=int(env.get("RATE_LIMIT") or 5),
            rate_window=int(env.get("RATE_WINDOW_SECONDS") or 600),
            repeat_hours=int(env.get("REPEAT_HOURS") or 24),
            trust_proxy=_bool(env.get("TRUST_PROXY"), False),
            thanks_url=env.get("THANKS_URL") or "/thanks",
            demo_page=_bool(env.get("DEMO_PAGE"), True),
            docs=_bool(env.get("API_DOCS"), True),
        )
