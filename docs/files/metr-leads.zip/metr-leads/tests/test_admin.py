"""Админка: вход, список и поиск, смена статуса, выгрузка для Excel, API для CRM."""

import csv
import io

from .conftest import ADMIN, lead_data

ORIGIN = {"Origin": "http://testserver"}


def add(client, **override):
    assert client.post("/api/leads", json=lead_data(**override)).status_code == 201


def test_admin_needs_password(client):
    r = client.get("/admin")
    assert r.status_code == 401 and r.headers["www-authenticate"].startswith("Basic")
    assert client.get("/admin", auth=("admin", "wrong")).status_code == 401
    assert client.get("/admin/leads.csv").status_code == 401
    assert client.get("/api/leads").status_code == 401
    assert client.get("/admin", auth=ADMIN).status_code == 200


def test_admin_is_off_without_password(make_client):
    client = make_client(admin_password="")
    r = client.get("/admin", auth=("admin", ""))
    assert r.status_code == 503 and "ADMIN_PASSWORD" in r.json()["detail"]


def test_list_tabs_and_spam_hidden_from_all(client):
    add(client)
    add(client, name="Олег", phone="+79030000001", service="cosmetic", area=None)
    add(client, name="Бот", phone="+79030000002", website="spam.example")
    page = client.get("/admin", auth=ADMIN).text
    assert 'id="lead-1"' in page and 'id="lead-2"' in page and 'id="lead-3"' not in page
    assert "+7 916 123-45-67" in page and "Ремонт под ключ · 54 м²" in page
    assert ">Все<span>2</span>" in page and ">Спам<span>1</span>" in page and ">Новые<span>2</span>" in page
    spam = client.get("/admin?status=spam", auth=ADMIN).text
    assert 'id="lead-3"' in spam and 'id="lead-1"' not in spam


def test_delivery_and_repeat_badges(client):
    add(client)
    add(client, comment="Ещё вопрос")
    client.portal.call(client.app.state.worker.run_once)
    add(client, name="Олег", phone="+79030000001")
    page = client.get("/admin", auth=ADMIN).text
    assert page.count("✓ В Telegram") == 2 and page.count(">В очереди<") == 1
    assert "Повторная · первая №1" in page


def test_search_by_name_comment_and_phone(client):
    add(client, name="Анна Петрова")
    add(client, name="Олег", phone="+7 903 555-12-34", comment="Санузел под ключ")
    found = lambda q: [lead["id"] for lead in client.get("/api/leads", params={"q": q}, auth=ADMIN).json()["items"]]  # noqa: E731
    assert found("анна") == [1]          # без учёта регистра, и по-русски тоже
    assert found("САНУЗЕЛ") == [2]
    assert found("8 903 555") == [2]     # 8 вместо +7
    assert found("55-12-34") == [2]     # хвост номера
    assert found("+7 916 123-45-67") == [1]
    assert found("кухня") == []


def test_status_change_from_admin_page(client):
    add(client)
    r = client.post("/admin/leads/1/status", data={"status": "in_work", "back": "/admin?status=new"},
                    auth=ADMIN, headers=ORIGIN, follow_redirects=False)
    assert r.status_code == 303 and r.headers["location"] == "/admin?status=new#lead-1"
    assert client.get("/api/leads", auth=ADMIN).json()["items"][0]["status"] == "in_work"


def test_status_change_from_other_site_is_blocked(client):
    add(client)
    for headers in ({}, {"Origin": "https://evil.example"}, {"Referer": "https://evil.example/page"}):
        r = client.post("/admin/leads/1/status", data={"status": "spam"}, auth=ADMIN, headers=headers)
        assert r.status_code == 403
    assert client.get("/api/leads", auth=ADMIN).json()["items"][0]["status"] == "new"


def test_status_change_rejects_unknown_status_and_lead(client):
    add(client)
    assert client.post("/admin/leads/1/status", data={"status": "lost"}, auth=ADMIN, headers=ORIGIN).status_code == 422
    assert client.post("/admin/leads/9/status", data={"status": "done"}, auth=ADMIN, headers=ORIGIN).status_code == 404


def test_redirect_after_status_stays_inside_admin(client):
    add(client)
    r = client.post("/admin/leads/1/status", data={"status": "done", "back": "https://evil.example"},
                    auth=ADMIN, headers=ORIGIN, follow_redirects=False)
    assert r.headers["location"] == "/admin#lead-1"


def test_csv_opens_in_excel(client, clock):
    add(client, utm_source="yandex", page="https://metr.example/remont")
    add(client, name="=HYPERLINK(\"http://evil.example\";\"Жми\")", phone="+79030000001", comment="-2+3", area=None)
    r = client.get("/admin/leads.csv", auth=ADMIN)
    assert r.status_code == 200
    assert r.headers["content-disposition"] == 'attachment; filename="leads-2025-11-03.csv"'
    assert r.content.startswith(b"\xef\xbb\xbf")  # BOM: Excel поймёт, что это UTF-8
    table = list(csv.reader(io.StringIO(r.content.decode("utf-8-sig")), delimiter=";"))
    assert table[0][:5] == ["№", "Дата", "Время", "Имя", "Телефон"]
    newest, oldest = table[1], table[2]
    assert oldest[:7] == ["1", "03.11.2025", "14:05", "Анна", "8 916 123-45-67", "Ремонт под ключ", "54"]
    assert oldest[8] == "Новая" and oldest[10] == "https://metr.example/remont" and oldest[11] == "yandex"
    assert newest[3].startswith("'=HYPERLINK") and newest[7] == "'-2+3"  # формулы не выполнятся


def test_csv_respects_filters(client):
    add(client)
    add(client, name="Олег", phone="+79030000001")
    client.patch("/api/leads/2", json={"status": "done"}, auth=ADMIN)
    table = list(csv.reader(io.StringIO(client.get("/admin/leads.csv?status=done", auth=ADMIN).text), delimiter=";"))
    assert len(table) == 2 and table[1][3] == "Олег"


def test_api_for_crm(client):
    add(client)
    data = client.get("/api/leads", auth=ADMIN).json()
    assert data["total"] == 1
    item = data["items"][0]
    assert item["phone"] == "+79161234567" and item["service_name"] == "Ремонт под ключ"
    assert item["created_at"] == "2025-11-03T11:05:00+00:00"
    patched = client.patch("/api/leads/1", json={"status": "done"}, auth=ADMIN)
    assert patched.status_code == 200 and patched.json()["status"] == "done"
    assert client.patch("/api/leads/1", json={"status": "lost"}, auth=ADMIN).status_code == 422
    assert client.patch("/api/leads/5", json={"status": "done"}, auth=ADMIN).status_code == 404
