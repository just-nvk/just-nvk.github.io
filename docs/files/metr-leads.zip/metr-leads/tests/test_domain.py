from datetime import UTC, datetime
from zoneinfo import ZoneInfo

import pytest

from metr_leads.domain import csv_safe, format_phone, format_phone_csv, human_time, normalize_phone

MSK = ZoneInfo("Europe/Moscow")


@pytest.mark.parametrize("raw", [
    "8 (916) 123-45-67",
    "+7 916 123 45 67",
    "+7(916)1234567",
    "7 916 123-45-67",
    "9161234567",
    "  89161234567  ",
    "8.916.123.45.67",
])
def test_phone_formats_people_type(raw):
    assert normalize_phone(raw) == "+79161234567"


def test_city_numbers_are_fine():
    assert normalize_phone("8 (495) 123-45-67") == "+74951234567"


@pytest.mark.parametrize("raw", [
    "123",
    "+1 916 123 45 67",       # чужая страна
    "+8 916 123 45 67",       # с плюсом — только +7
    "8 916 123 45 6",         # не хватает цифры
    "8 916 123 45 678",       # лишняя цифра
    "+9161234567",            # плюс без кода страны
    "8 116 123-45-67",        # таких кодов нет
    "8 916 123-45-67 доб. 5",
    "телефон",
])
def test_bad_phones_are_rejected(raw):
    with pytest.raises(ValueError, match="Проверьте номер"):
        normalize_phone(raw)


def test_phone_display_and_excel():
    assert format_phone("+79161234567") == "+7 916 123-45-67"
    assert format_phone_csv("+79161234567") == "8 916 123-45-67"


def test_human_time_uses_company_timezone():
    now = datetime(2025, 11, 3, 11, 5, tzinfo=UTC)  # 14:05 в Москве
    assert human_time(datetime(2025, 11, 3, 8, 0, tzinfo=UTC), now, MSK) == "сегодня в 11:00"
    # 22:30 UTC 2 ноября — уже 01:30 3 ноября по Москве: «сегодня», а не «вчера»
    assert human_time(datetime(2025, 11, 2, 22, 30, tzinfo=UTC), now, MSK) == "сегодня в 01:30"
    assert human_time(datetime(2025, 11, 2, 6, 30, tzinfo=UTC), now, MSK) == "вчера в 09:30"
    assert human_time(datetime(2025, 10, 28, 9, 0, tzinfo=UTC), now, MSK) == "28 октября в 12:00"
    assert human_time(datetime(2024, 12, 31, 9, 0, tzinfo=UTC), now, MSK) == "31 декабря 2024 в 12:00"


@pytest.mark.parametrize(("value", "expected"), [
    ("=HYPERLINK(\"http://evil\")", "'=HYPERLINK(\"http://evil\")"),
    ("+7 916", "'+7 916"),
    ("-1", "'-1"),
    ("@SUM(A1)", "'@SUM(A1)"),
    ("Анна", "Анна"),
    (None, ""),
    (54, "54"),
])
def test_csv_safe_blocks_formulas(value, expected):
    assert csv_safe(value) == expected
