"""Общие заготовки: часы, которые можно подвинуть, поддельный Telegram и клиент к приложению."""

from __future__ import annotations

import json
from dataclasses import replace
from datetime import UTC, datetime, timedelta
from pathlib import Path

import httpx
import pytest
from fastapi.testclient import TestClient

from metr_leads.app import create_app
from metr_leads.config import Company, Settings
from metr_leads.schemas import LeadIn

ROOT = Path(__file__).resolve().parent.parent
COMPANY = ROOT / "company.toml"
START = datetime(2025, 11, 3, 11, 5, tzinfo=UTC)  # 14:05 по Москве


class FakeClock:
    def __init__(self, now: datetime = START):
        self.now = now

    def __call__(self) -> datetime:
        return self.now

    def advance(self, **delta: float) -> None:
        self.now += timedelta(**delta)


class FakeTelegram:
    """Вместо api.telegram.org. Ответы можно задать заранее: (код, json) или исключение."""

    def __init__(self):
        self.sent: list[dict] = []
        self.calls = 0
        self.responses: list = []
        self.transport = httpx.MockTransport(self._handle)

    def _handle(self, request: httpx.Request) -> httpx.Response:
        self.calls += 1
        status, body = 200, {"ok": True, "result": {"message_id": self.calls}}
        if self.responses:
            answer = self.responses.pop(0)
            if isinstance(answer, Exception):
                raise answer
            status, body = answer
        if status == 200:
            self.sent.append(json.loads(request.content))
        return httpx.Response(status, json=body)

    def fail_network(self, times: int = 1) -> None:
        self.responses += [httpx.ConnectError("нет сети")] * times


def lead_data(**override) -> dict:
    data = {"name": "Анна", "phone": "8 (916) 123-45-67", "service": "turnkey", "area": 54,
            "comment": "Двушка в новостройке, хотим начать в декабре", "consent": True}
    data.update(override)
    return data


def lead_in(**override) -> LeadIn:
    return LeadIn.model_validate(lead_data(**override), context={"services": Company.load(COMPANY).services})


@pytest.fixture
def clock() -> FakeClock:
    return FakeClock()


@pytest.fixture
def telegram() -> FakeTelegram:
    return FakeTelegram()


@pytest.fixture
def company() -> Company:
    return Company.load(COMPANY)


@pytest.fixture
def settings(tmp_path: Path) -> Settings:
    return Settings(
        db_path=tmp_path / "leads.db",
        company_path=COMPANY,
        telegram_token="123:TEST",
        telegram_chat_id="-1001",
        admin_user="admin",
        admin_password="secret",
        admin_url="https://leads.metr.example/admin",
        allowed_origins=("https://metr.example",),
    )


@pytest.fixture
def make_client(settings, clock, telegram):
    """make_client(rate_limit=2, …) — приложение с изменёнными настройками. Фоновый воркер выключен."""
    opened: list[TestClient] = []

    def make(start_worker: bool = False, **changes) -> TestClient:
        app = create_app(replace(settings, **changes), clock=clock, telegram_transport=telegram.transport,
                         start_worker=start_worker)
        client = TestClient(app)
        client.__enter__()
        opened.append(client)
        return client

    yield make
    for client in opened:
        client.__exit__(None, None, None)


@pytest.fixture
def client(make_client) -> TestClient:
    return make_client()


ADMIN = ("admin", "secret")
