"""Уведомления: текст сообщения, очередь, повторы при сбоях Telegram."""

import asyncio
import time

import httpx

from metr_leads.outbox import BACKOFF, OutboxWorker
from metr_leads.storage import Storage
from metr_leads.telegram import Telegram, lead_message, short_page

from .conftest import lead_data, lead_in

ADMIN_URL = "https://leads.metr.example/admin"


def make_worker(tmp_path, clock, telegram, company):
    storage = Storage(tmp_path / "leads.db")
    client = httpx.AsyncClient(base_url="https://api.telegram.org", transport=telegram.transport)
    worker = OutboxWorker(storage, Telegram("123:TEST", "-1001", client), company, clock, ADMIN_URL)
    return storage, worker


def run(worker) -> int:
    return asyncio.run(worker.run_once())


def test_message_text(tmp_path, clock, company):
    storage = Storage(tmp_path / "leads.db")
    lead, _ = storage.add_lead(lead_in(page="https://metr.example/remont?utm_source=yandex", utm_source="yandex",
                                       utm_medium="cpc", utm_campaign="remont-msk"), clock(), 24)
    text, markup = lead_message(lead, company, clock(), admin_url=ADMIN_URL)
    assert text == (
        "<b>Новая заявка №1</b>\n"
        "Ремонт под ключ · 54 м²\n"
        "\n"
        "Имя: Анна\n"
        "Телефон: +7 916 123-45-67\n"
        "Комментарий: Двушка в новостройке, хотим начать в декабре\n"
        "\n"
        "Откуда: metr.example/remont · yandex · cpc · remont-msk\n"
        "Пришла сегодня в 14:05"
    )
    assert markup == {"inline_keyboard": [[{"text": "Открыть в админке", "url": f"{ADMIN_URL}#lead-1"}]]}


def test_repeat_message_points_to_first(tmp_path, clock, company):
    storage = Storage(tmp_path / "leads.db")
    first, _ = storage.add_lead(lead_in(), clock(), 24)
    clock.advance(hours=2)
    again, _ = storage.add_lead(lead_in(comment="", area=None, service="design"), clock(), 24)
    text, _ = lead_message(again, company, clock(), first)
    assert text.splitlines()[:3] == ["<b>Повторная заявка №2</b>", "Дизайн-проект", "Первая — №1, сегодня в 14:05"]
    assert "Комментарий" not in text and "Откуда" not in text


def test_visitor_text_is_escaped(tmp_path, clock, company):
    storage = Storage(tmp_path / "leads.db")
    lead, _ = storage.add_lead(lead_in(name="<b>Иван</b> & Co", comment='<a href="x">жми</a>'), clock(), 24)
    text, markup = lead_message(lead, company, clock())
    assert "Имя: &lt;b&gt;Иван&lt;/b&gt; &amp; Co" in text
    assert "&lt;a href=&quot;x&quot;&gt;жми&lt;/a&gt;" in text
    assert markup is None  # адрес админки не задан — без кнопки


def test_short_page():
    assert short_page("https://metr.example/remont/?utm_source=vk#form") == "metr.example/remont"
    assert short_page("metr.example") == "metr.example"
    assert short_page("") == ""


def test_worker_sends_once(tmp_path, clock, telegram, company):
    storage, worker = make_worker(tmp_path, clock, telegram, company)
    storage.add_lead(lead_in(), clock(), 24)
    assert run(worker) == 1
    assert run(worker) == 0
    [payload] = telegram.sent
    assert payload["chat_id"] == "-1001" and payload["parse_mode"] == "HTML"
    assert payload["text"].startswith("<b>Новая заявка №1</b>")
    assert storage.outbox_stats(clock())["pending"] == 0


def test_network_error_retries_with_growing_pause(tmp_path, clock, telegram, company):
    storage, worker = make_worker(tmp_path, clock, telegram, company)
    storage.add_lead(lead_in(), clock(), 24)
    telegram.fail_network(times=3)
    for pause in BACKOFF[:3]:
        assert run(worker) == 0
        clock.advance(seconds=pause - 1)
        assert run(worker) == 0  # ещё рано — Telegram не дёргаем
        clock.advance(seconds=1)
    assert telegram.calls == 3
    assert run(worker) == 1
    assert len(telegram.sent) == 1


def test_telegram_flood_limit_is_respected(tmp_path, clock, telegram, company):
    storage, worker = make_worker(tmp_path, clock, telegram, company)
    storage.add_lead(lead_in(), clock(), 24)
    storage.add_lead(lead_in(phone="+79030000001"), clock(), 24)
    flood = {"ok": False, "description": "Too Many Requests", "parameters": {"retry_after": 7}}
    telegram.responses.append((429, flood))
    assert run(worker) == 0
    assert telegram.calls == 1  # вторую заявку в этот круг даже не пробовали
    clock.advance(seconds=7)
    assert run(worker) == 2


def test_wrong_settings_do_not_spam_telegram(tmp_path, clock, telegram, company):
    storage, worker = make_worker(tmp_path, clock, telegram, company)
    storage.add_lead(lead_in(), clock(), 24)
    storage.add_lead(lead_in(phone="+79030000001"), clock(), 24)
    telegram.responses.append((403, {"ok": False, "description": "Forbidden: bot was kicked from the group chat"}))
    assert run(worker) == 0 and telegram.calls == 1
    stats = storage.outbox_stats(clock())
    assert stats["pending"] == 2 and "kicked" in stats["last_error"]
    clock.advance(minutes=59)
    assert run(worker) == 1  # вторая заявка в очереди не застряла: её очередь не трогали
    clock.advance(minutes=1)
    assert run(worker) == 1  # бота вернули в чат — первая ушла через час


def test_lead_survives_telegram_outage_and_restart(tmp_path, clock, telegram, company):
    storage, worker = make_worker(tmp_path, clock, telegram, company)
    storage.add_lead(lead_in(), clock(), 24)
    telegram.fail_network()
    run(worker)
    clock.advance(minutes=10)
    _, restarted = make_worker(tmp_path, clock, telegram, company)  # новый процесс, та же база
    assert run(restarted) == 1
    assert "Новая заявка №1" in telegram.sent[0]["text"]


def test_stuck_notifications_show_in_health(make_client, clock, telegram):
    client = make_client()
    assert client.get("/health").json()["status"] == "ok"
    client.post("/api/leads", json=lead_data())  # воркер выключен — уведомление висит в очереди
    clock.advance(minutes=11)
    health = client.get("/health").json()
    assert health["status"] == "degraded"
    assert health["outbox"]["pending"] == 1 and health["outbox"]["oldest_pending_minutes"] == 11


def test_notification_goes_out_right_after_the_form(make_client, telegram):
    client = make_client(start_worker=True)
    client.app.state.worker.interval = 60  # без «пинка» воркер ждал бы минуту
    client.post("/api/leads", json=lead_data())
    deadline = time.monotonic() + 3
    while not telegram.sent and time.monotonic() < deadline:
        time.sleep(0.02)
    assert len(telegram.sent) == 1
    assert telegram.sent[0]["reply_markup"]["inline_keyboard"][0][0]["url"].endswith("#lead-1")


def test_without_telegram_leads_wait_in_queue(make_client, settings):
    client = make_client(telegram_token="")
    assert client.post("/api/leads", json=lead_data()).status_code == 201
    assert client.app.state.worker is None
    assert client.get("/health").json() == {
        "status": "degraded", "telegram": False,
        "outbox": {"pending": 1, "oldest_pending_minutes": 0, "last_error": None}}
