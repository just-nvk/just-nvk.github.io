"""Приём заявок: проверка полей, защита от спама и дублей, повторные обращения."""

import sqlite3

from .conftest import lead_data


def rows(settings, sql="SELECT * FROM leads ORDER BY id"):
    conn = sqlite3.connect(settings.db_path)
    conn.row_factory = sqlite3.Row
    try:
        return [dict(r) for r in conn.execute(sql)]
    finally:
        conn.close()


def test_lead_is_saved_and_queued(client, settings):
    r = client.post("/api/leads", json=lead_data(page="https://metr.example/remont?utm_source=yandex"))
    assert r.status_code == 201
    assert r.json() == {"ok": True, "message": "Заявка у нас — перезвоним в течение часа в рабочее время."}
    [lead] = rows(settings)
    assert lead["phone"] == "+79161234567"
    assert lead["status"] == "new" and lead["area"] == 54 and lead["repeat_of"] is None
    assert len(rows(settings, "SELECT * FROM outbox")) == 1


def test_answer_does_not_reveal_lead_number(client):
    """По номерам заявок конкурент посчитал бы, сколько обращений получает компания."""
    first = client.post("/api/leads", json=lead_data()).json()
    second = client.post("/api/leads", json=lead_data(phone="+7 903 000-00-01")).json()
    assert "id" not in first and first == second


def test_errors_are_in_russian_for_each_field(client, settings):
    r = client.post("/api/leads", json={"name": "А", "phone": "123", "service": "roof", "area": 3,
                                        "comment": "х" * 1001, "consent": False})
    assert r.status_code == 422
    assert r.json()["errors"] == {
        "name": "Как к вам обращаться? Нужно от 2 до 80 символов",
        "phone": "Проверьте номер: нужен российский, +7 и 10 цифр",
        "service": "Выберите вид работ",
        "area": "Площадь — целое число от 5 до 2000 м²",
        "comment": "Комментарий — не длиннее 1000 символов",
        "consent": "Нужно согласие на обработку персональных данных",
    }
    assert rows(settings) == []


def test_missing_fields_get_the_same_messages(client):
    r = client.post("/api/leads", json={})
    assert set(r.json()["errors"]) == {"name", "phone", "service", "consent"}


def test_area_is_optional_and_accepts_text_from_form(client, settings):
    assert client.post("/api/leads", json=lead_data(area="")).status_code == 201
    assert client.post("/api/leads", json=lead_data(area="72", phone="+79030000001")).status_code == 201
    assert [r["area"] for r in rows(settings)] == [None, 72]
    assert client.post("/api/leads", json=lead_data(area=2001)).json()["errors"] == {
        "area": "Площадь — целое число от 5 до 2000 м²"}


def test_spaces_trimmed_and_unknown_fields_ignored(client, settings):
    client.post("/api/leads", json=lead_data(name="  Анна  ", role="admin", status="done"))
    [lead] = rows(settings)
    assert lead["name"] == "Анна" and lead["status"] == "new"


def test_honeypot_looks_like_success_but_goes_to_spam(client, settings):
    r = client.post("/api/leads", json=lead_data(website="http://casino.example"))
    assert r.status_code == 201 and r.json()["ok"] is True
    [lead] = rows(settings)
    assert lead["status"] == "spam"
    assert rows(settings, "SELECT * FROM outbox") == []  # менеджеров не беспокоим


def test_same_form_sent_twice_creates_one_lead(client, settings):
    data = lead_data(request_id="5f1c0e9a-77aa-4c2b-9d3e-0b1e2f3a4b5c")
    assert client.post("/api/leads", json=data).status_code == 201
    again = client.post("/api/leads", json=data)
    assert again.status_code == 200 and again.json()["ok"] is True
    assert len(rows(settings)) == 1
    assert len(rows(settings, "SELECT * FROM outbox")) == 1


def test_repeat_within_24_hours_links_to_first(client, settings, clock):
    client.post("/api/leads", json=lead_data())
    clock.advance(hours=3)
    client.post("/api/leads", json=lead_data(phone="+7 916 123 45 67", comment="Забыла сказать про санузел"))
    clock.advance(hours=5)
    client.post("/api/leads", json=lead_data(phone="9161234567"))
    assert [r["repeat_of"] for r in rows(settings)] == [None, 1, 1]  # все повторы ссылаются на первую


def test_after_24_hours_it_is_a_new_lead(client, settings, clock):
    client.post("/api/leads", json=lead_data())
    clock.advance(hours=25)
    client.post("/api/leads", json=lead_data())
    assert [r["repeat_of"] for r in rows(settings)] == [None, None]


def test_spam_does_not_make_next_lead_a_repeat(client, settings):
    client.post("/api/leads", json=lead_data(website="x"))
    client.post("/api/leads", json=lead_data())
    assert [r["repeat_of"] for r in rows(settings)] == [None, None]


def test_plain_html_form_redirects_to_thanks(client, settings):
    form = {"name": "Пётр", "phone": "+7 999 111-22-33", "service": "design", "area": "", "consent": "1",
            "request_id": "a1b2c3d4e5f6a7b8", "website": ""}
    r = client.post("/api/leads", data=form, follow_redirects=False)
    assert r.status_code == 303 and r.headers["location"] == "/thanks"
    [lead] = rows(settings)
    assert lead["phone"] == "+79991112233" and lead["area"] is None


def test_plain_html_form_errors_are_shown_on_page(client, settings):
    r = client.post("/api/leads", data={"name": "Пётр", "phone": "12", "service": "design"})
    assert r.status_code == 422 and r.headers["content-type"].startswith("text/html")
    assert "Проверьте номер" in r.text and "Нужно согласие" in r.text
    assert rows(settings) == []


def test_page_taken_from_referer_when_missing(client, settings):
    client.post("/api/leads", json=lead_data(), headers={"Referer": "https://metr.example/dizain"})
    assert rows(settings)[0]["page"] == "https://metr.example/dizain"


def test_wrong_requests_are_rejected_politely(client):
    assert client.post("/api/leads", content="name=Анна", headers={"Content-Type": "text/plain"}).status_code == 415
    assert client.post("/api/leads", content="[1, 2]", headers={"Content-Type": "application/json"}).status_code == 400
    assert client.post("/api/leads", content="{oops", headers={"Content-Type": "application/json"}).status_code == 400
    huge = client.post("/api/leads", json=lead_data(comment="х" * 30_000))
    assert huge.status_code == 413


def test_rate_limit_per_ip_with_window(make_client, clock):
    client = make_client(rate_limit=3, rate_window=600)
    for i in range(3):
        assert client.post("/api/leads", json=lead_data(phone=f"+7903000000{i}")).status_code == 201
    clock.advance(seconds=60)
    r = client.post("/api/leads", json=lead_data(phone="+79030000009"))
    assert r.status_code == 429
    assert r.headers["retry-after"] == "540"
    assert r.json()["message"] == "Слишком много заявок подряд. Попробуйте через 9 мин или позвоните нам."
    clock.advance(seconds=541)
    assert client.post("/api/leads", json=lead_data(phone="+79030000009")).status_code == 201


def test_retry_of_same_form_is_not_blocked_by_rate_limit(make_client):
    client = make_client(rate_limit=1)
    data = lead_data(request_id="same-form-123")
    assert client.post("/api/leads", json=data).status_code == 201
    assert client.post("/api/leads", json=data).status_code == 200


def test_proxy_headers_trusted_only_when_enabled(make_client):
    direct = make_client(rate_limit=1)
    direct.post("/api/leads", json=lead_data(), headers={"X-Real-IP": "1.1.1.1"})
    # Без прокси заголовок подделывается — лимит всё равно по настоящему адресу.
    assert direct.post("/api/leads", json=lead_data(), headers={"X-Real-IP": "2.2.2.2"}).status_code == 429

    proxied = make_client(rate_limit=1, trust_proxy=True, db_path=direct.app.state.settings.db_path.with_name("p.db"))
    assert proxied.post("/api/leads", json=lead_data(), headers={"X-Real-IP": "1.1.1.1"}).status_code == 201
    assert proxied.post("/api/leads", json=lead_data(), headers={"X-Real-IP": "2.2.2.2"}).status_code == 201
    assert proxied.post("/api/leads", json=lead_data(), headers={"X-Real-IP": "1.1.1.1"}).status_code == 429


def test_cors_only_for_company_site(client):
    preflight = {"Access-Control-Request-Method": "POST", "Access-Control-Request-Headers": "content-type"}
    ok = client.options("/api/leads", headers={"Origin": "https://metr.example", **preflight})
    assert ok.status_code == 200 and ok.headers["access-control-allow-origin"] == "https://metr.example"
    bad = client.options("/api/leads", headers={"Origin": "https://evil.example", **preflight})
    assert "access-control-allow-origin" not in bad.headers


def test_demo_page_has_form_with_request_id(client, make_client):
    page = client.get("/")
    assert page.status_code == 200
    assert 'name="request_id" value="' in page.text and "Ремонт под ключ" in page.text
    assert client.get("/thanks").status_code == 200
    hidden = make_client(demo_page=False, docs=False)
    assert "form" not in hidden.get("/").text
    assert hidden.get("/docs").status_code == 404
