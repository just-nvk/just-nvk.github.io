from datetime import datetime

import openpyxl
import pytest
from conftest import raw, rec, source

from polka_report.aggregate import aggregate
from polka_report.clean import build
from polka_report.report import BADGE_OK, BADGE_WARN, report_name, write_report

CREATED = datetime(2026, 11, 3, 9, 0)
SHEETS = ["Сводка", "По дням", "Товары", "Проверки", "Данные"]


@pytest.fixture(scope="module")
def book(result, config, tmp_path_factory):
    path = tmp_path_factory.mktemp("report") / report_name(config.company, result.month)
    rep = write_report(result, path, config.company, config.abc_a, config.abc_b, created=CREATED)
    return rep, openpyxl.load_workbook(path), openpyxl.load_workbook(path, data_only=True)


def test_name(config, result):
    assert report_name(config.company, result.month) == "Полка — продажи за октябрь 2026.xlsx"


def test_sheets_and_sales_table(book, result):
    _, wb, _ = book
    assert wb.sheetnames == SHEETS
    data = wb["Данные"]
    assert data.tables["Продажи"].ref == f"A1:O{len(result.rows) + 1}"
    assert [c.value for c in data[1]][:10] == ["Дата", "Магазин", "Чек", "Строка", "Артикул", "Товар", "Категория",
                                               "Операция", "Количество", "Сумма"]


def test_totals_are_formulas_over_the_table(book):
    _, wb, _ = book
    s = wb["Сводка"]
    assert s["B6"].value == "=C14"  # карточка «Выручка» = итог таблицы магазинов
    assert s["C11"].value == "=SUMIFS(Продажи[Сумма],Продажи[Магазин],$B11)"
    assert s["M11"].value.startswith("=SUM('Проверки'!$C$5:$C$8")
    assert wb["Товары"]["K2"].value == '=IF(J2-I2<$N$2,"A",IF(J2-I2<$N$3,"B","C"))'
    assert wb["Данные"]["L2"].value == '=IF(K2="","",J2-I2*K2)'


@pytest.mark.parametrize("sheet", ["Сводка", "По дням", "Товары", "Проверки"])
def test_no_hardcoded_totals(book, sheet):
    """Числа на итоговых листах — только формулы. Исключения: даты, пороги ABC и счётчики сверки из выгрузок."""
    _, wb, _ = book
    allowed = {"Товары": {"N2", "N3"}}.get(sheet, set())
    for row in wb[sheet].iter_rows():
        for c in row:
            if isinstance(c.value, int | float) and c.coordinate not in allowed:
                assert sheet == "Проверки" and c.column_letter not in "DIJMN", f"{sheet}!{c.coordinate} = {c.value}"


def test_saved_values_match_pandas(book):
    rep, _, values = book
    s, t = values["Сводка"], rep.total
    assert s["B6"].value == pytest.approx(t.revenue)
    assert s["E6"].value == pytest.approx(t.profit)
    assert s["H6"].value == t.receipts
    assert s["K6"].value == pytest.approx(t.returns)
    assert [s[f"B{r}"].value for r in (11, 12, 13)] == ["Тверская", "Лефортово", "Сайт"]
    assert sum(s[f"C{r}"].value for r in (11, 12, 13)) == pytest.approx(s["C14"].value)
    assert s["K10"].value == BADGE_WARN  # в примерах есть строки с ошибками
    assert [s[f"M{r}"].value for r in range(11, 16)] == [5691, 5369, 147, 173, 2]
    assert values["По дням"]["E33"].value == pytest.approx(t.revenue)
    assert values["Проверки"]["N7"].value == "Есть строки с ошибками"


def test_formats(book):
    _, wb, _ = book
    d, s = wb["Данные"], wb["Сводка"]
    assert d["A2"].number_format == "dd.mm.yyyy" and d["J2"].number_format == "#,##0.00"
    assert d["C2"].data_type == "s"  # номер чека — текст, «7872» и «S-10001» хранятся одинаково
    assert s["C11"].number_format == '#,##0 "₽"' and s["D11"].number_format == "0.0%"
    assert s.page_setup.orientation == "landscape" and s.sheet_properties.pageSetUpPr.fitToPage
    assert s.page_setup.fitToHeight in (None, 1)  # сводка печатается на одном листе A4


def test_abc_classes(result):
    p = aggregate(result, 0.8, 0.95).products
    prev = p.cum - p.share
    assert (p.abc[prev < 0.8] == "A").all() and (p.abc[(prev >= 0.8) & (prev < 0.95)] == "B").all()
    assert (p.abc[prev >= 0.95] == "C").all()
    assert p.revenue.is_monotonic_decreasing and p.cum.iloc[-1] == pytest.approx(1.0)
    assert (aggregate(result, 0.5, 0.9).products.abc == "A").sum() < (p.abc == "A").sum()


def test_clean_month_gets_green_badge(tmp_path):
    src = source()
    res = build([raw("kassa.csv", src, rec(), rec(receipt="2", amount="250,50"), total=350.5)],
                {"PL-1001": {"name": "Плед", "category": "Текстиль", "cost": 40.0}})
    path = tmp_path / "r.xlsx"
    write_report(res, path, "Тест", created=CREATED)
    v = openpyxl.load_workbook(path, data_only=True)
    assert v["Сводка"]["K10"].value == BADGE_OK
    assert v["Проверки"]["N5"].value == "Сходится"
    assert v["Проверки"]["A9"].value == "Нет — все строки разобраны."
