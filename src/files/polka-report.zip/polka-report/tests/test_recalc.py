"""Формулы пересчитывает LibreOffice — и они должны дать ровно те же цифры, что pandas.

Отчёт записывается дважды: с готовыми значениями и с нулями вместо них. Файл с нулями пересчитывается
в LibreOffice, после чего каждая формула сверяется со значением из pandas.
"""
import openpyxl
import pytest
from lo import recalculate, soffice

from polka_report.report import write_report

pytestmark = pytest.mark.skipif(soffice() is None, reason="нужен LibreOffice (soffice)")


def _same(a, b) -> bool:
    if isinstance(a, int | float) and isinstance(b, int | float):
        return abs(a - b) < 1e-6
    return (a in ("", None) and b in ("", None)) or a == b


def test_formulas_recalculate_to_pandas_values(result, config, tmp_path):
    write_report(result, tmp_path / "cached.xlsx", config.company)
    (tmp_path / "zero").mkdir()
    write_report(result, tmp_path / "zero" / "report.xlsx", config.company, cached=False)
    out = recalculate(tmp_path / "zero" / "report.xlsx", tmp_path / "out")

    formulas = openpyxl.load_workbook(tmp_path / "cached.xlsx")
    expected = openpyxl.load_workbook(tmp_path / "cached.xlsx", data_only=True)
    actual = openpyxl.load_workbook(out, data_only=True)
    assert actual["Сводка"]["B6"].value == pytest.approx(6_236_767)  # LibreOffice действительно пересчитал

    checked, wrong = 0, []
    for ws in formulas.worksheets:
        for row in ws.iter_rows():
            for c in row:
                if isinstance(c.value, str) and c.value.startswith("="):
                    checked += 1
                    a, b = expected[ws.title][c.coordinate].value, actual[ws.title][c.coordinate].value
                    if not _same(a, b):
                        wrong.append(f"{ws.title}!{c.coordinate}: pandas {a!r}, Excel {b!r}, {c.value[:80]}")
    assert checked > 5000
    assert not wrong, "\n".join(wrong[:20])
