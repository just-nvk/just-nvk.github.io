import re

import pytest

from polka_report.config import ConfigError, load

SOURCE = '''
[catalog]
file = "cat.xlsx"
[[source]]
name = "Касса"
files = "*.csv"
[source.columns]
date = "Дата"
receipt = "Чек"
sku = "Артикул"
qty = "Кол-во"
'''


def config(tmp_path, text):
    path = tmp_path / "polka.toml"
    path.write_text(text, encoding="utf-8")
    return load(path)


def test_example_config(config):
    assert config.company == "Полка"
    assert [s.name for s in config.sources] == ["Тверская", "Лефортово", "Сайт"]
    site = config.sources[2]
    assert site.sales == ("доставлен",) and site.skip == ("отменён", "отменен")
    assert config.catalog.file.name == "catalog.xlsx" and config.catalog.file.is_absolute()


def test_relative_paths_are_from_config_folder(tmp_path):
    c = config(tmp_path, SOURCE + 'amount = "Сумма"\n')
    assert c.exports == tmp_path / "exports" and c.catalog.file == tmp_path / "cat.xlsx"


@pytest.mark.parametrize("text, message", [
    (SOURCE, "не указаны колонки для полей: amount (сумма)"),
    (SOURCE + 'amount = "Сумма"\nprice = "Цена"\n', "неизвестные поля в [source.columns]: price"),
    (SOURCE.replace('files = "*.csv"', "") + 'amount = "Сумма"\n', "не указано, какие файлы читать"),
    (SOURCE + 'amount = "Сумма"\n[abc]\na = 0.95\nb = 0.8\n', "Пороги ABC должны идти по возрастанию"),
    (SOURCE.replace("[catalog]\nfile = \"cat.xlsx\"", "") + 'amount = "Сумма"\n', "не указан справочник товаров"),
    ('company = "Полка"\n[catalog]\nfile = "c.xlsx"\n', "нет ни одного источника"),
    ("company = Полка", "Ошибка в polka.toml"),
], ids=["no-amount", "unknown-field", "no-files", "abc-order", "no-catalog", "no-sources", "bad-toml"])
def test_config_errors(tmp_path, text, message):
    with pytest.raises(ConfigError, match=re.escape(message)):
        config(tmp_path, text)
