from __future__ import annotations

from pathlib import Path

import pytest

from polka_report.clean import load_all
from polka_report.config import Source, load
from polka_report.readers import RawFile

ROOT = Path(__file__).resolve().parent.parent


@pytest.fixture(scope="session")
def config():
    return load(ROOT / "polka.toml")


@pytest.fixture(scope="session")
def result(config):
    """Примеры выгрузок из examples/ — те же, что в README и на скриншотах."""
    return load_all(config)


def source(**kw) -> Source:
    columns = kw.pop("columns", None) or {"date": "Дата", "receipt": "Чек", "line": "Позиция", "sku": "Артикул",
                                          "name": "Товар", "qty": "Кол-во", "amount": "Сумма"}
    return Source(name=kw.pop("name", "Касса"), files=kw.pop("files", "*.csv"), columns=columns, **kw)


def raw(name: str, src: Source, *records: dict, start: int = 2, total: float | None = None) -> RawFile:
    """RawFile из словарей: номера строк идут подряд с start — как в файле, где шапка в первой строке."""
    rows = [(start + i, r) for i, r in enumerate(records)]
    return RawFile(path=Path(name), source=src, rows=rows, stated_total=total)


def rec(date="05.10.2026", receipt="101", line="1", sku="PL-1001", name="Товар", qty="1", amount="100", **kw) -> dict:
    out = {"date": date, "receipt": receipt, "line": line, "sku": sku, "name": name, "qty": qty, "amount": amount}
    out.update(kw)
    return out
