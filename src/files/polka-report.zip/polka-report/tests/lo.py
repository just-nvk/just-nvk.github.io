"""Пересчёт формул в LibreOffice — проверка, что формулы Excel сами дают те же цифры, что и pandas."""
from __future__ import annotations

import shutil
import subprocess
import tempfile
from pathlib import Path

# Профиль LibreOffice, в котором формулы из .xlsx всегда пересчитываются при открытии
# (по умолчанию LibreOffice доверяет сохранённым значениям).
_XCU = """<?xml version="1.0" encoding="UTF-8"?>
<oor:items xmlns:oor="http://openoffice.org/2001/registry" xmlns:xs="http://www.w3.org/2001/XMLSchema"
 xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
<item oor:path="/org.openoffice.Office.Calc/Formula/Load">
 <prop oor:name="OOXMLRecalcMode" oor:op="fuse"><value>0</value></prop>
</item>
</oor:items>"""


def soffice() -> str | None:
    return shutil.which("soffice") or shutil.which("libreoffice")


def recalculate(path: Path, out_dir: Path) -> Path:
    with tempfile.TemporaryDirectory() as tmp:
        profile = Path(tmp) / "profile"
        (profile / "user").mkdir(parents=True)
        (profile / "user" / "registrymodifications.xcu").write_text(_XCU, encoding="utf-8")
        subprocess.run([soffice(), "--headless", "--norestore", f"-env:UserInstallation={profile.as_uri()}",
                        "--convert-to", "xlsx:Calc MS Excel 2007 XML", "--outdir", str(out_dir), str(path)],
                       check=True, capture_output=True, timeout=180)
    return out_dir / path.name
