import pytest
from conftest import source
from openpyxl import Workbook

from polka_report.config import Catalog, ConfigError
from polka_report.readers import find_files, read_catalog, read_export

HEAD = "Дата;Чек;Позиция;Артикул;Товар;Кол-во;Сумма"


def write(path, text, encoding="utf-8"):
    path.write_bytes(text.encode(encoding))
    return path


@pytest.mark.parametrize("encoding", ["utf-8", "utf-8-sig", "cp1251"])
def test_csv_encodings(tmp_path, encoding):
    f = write(tmp_path / "a.csv", f"{HEAD}\n01.10.2026;7;1;PL-1001;Плед «Ёлка»;1;2790,00\n", encoding)
    raw = read_export(f, source())
    assert [r["name"] for _, r in raw.rows] == ["Плед «Ёлка»"]


@pytest.mark.parametrize("sep", [";", ",", "\t", "|"])
def test_csv_delimiters(tmp_path, sep):
    text = HEAD.replace(";", sep) + "\n" + sep.join(["01.10.2026", "7", "1", "PL-1001", "Плед", "1", "2790"]) + "\n"
    raw = read_export(write(tmp_path / "a.csv", text), source())
    assert raw.rows[0][1]["amount"] == "2790"


def test_header_not_first_and_columns_in_any_order(tmp_path):
    text = ("Отчёт о продажах;;\nПериод: октябрь 2026;;\n\n"
            "Сумма;Кол-во;Товар;Артикул;Позиция;Чек;Дата;Кассир\n"
            "2790;1;Плед;PL-1001;1;7;01.10.2026;Анна\n")
    raw = read_export(write(tmp_path / "a.csv", text), source())
    line, r = raw.rows[0]
    assert line == 5  # номер строки в файле — чтобы найти её глазами
    assert (r["date"], r["sku"], r["amount"]) == ("01.10.2026", "PL-1001", "2790")


def test_header_match_ignores_case_spaces_and_yo(tmp_path):
    text = " дата ;ЧЕК;Позиция;Артикул;Товар;Кол-во;Сумма\n01.10.2026;7;1;PL-1001;Плед;1;2790\n"
    assert len(read_export(write(tmp_path / "a.csv", text), source()).rows) == 1


def test_total_row_and_blank_lines(tmp_path):
    text = (f"{HEAD}\n01.10.2026;7;1;PL-1001;Плед;1;2790\n;;;;;;\n"
            "01.10.2026;8;1;PL-1002;Доска;2;1780\nИтого;;;;;3;4 570,00\n")
    raw = read_export(write(tmp_path / "a.csv", text), source())
    assert len(raw.rows) == 2
    assert raw.stated_total == 4570.0


def test_quoted_field_with_newline_keeps_row_numbers(tmp_path):
    text = f'{HEAD}\n01.10.2026;7;1;PL-1001;"Плед\nбольшой";1;2790\n01.10.2026;8;1;PL-1002;Доска;1;890\n'
    raw = read_export(write(tmp_path / "a.csv", text), source())
    assert [line for line, _ in raw.rows] == [2, 4]


def test_missing_column_message(tmp_path):
    f = write(tmp_path / "kassa.csv", "Дата;Чек;Артикул;Товар;Кол-во;Итог\n01.10.2026;7;PL-1;Плед;1;10\n")
    with pytest.raises(ConfigError) as e:
        read_export(f, source())
    msg = str(e.value)
    assert "kassa.csv" in msg and "«Позиция» (номер строки в чеке)" in msg and "«Сумма» (сумма)" in msg
    assert "Колонки в файле: Дата, Чек, Артикул, Товар, Кол-во, Итог" in msg
    assert "[source.columns] для «Касса»" in msg


def test_xlsx_with_title_rows_and_sheet(tmp_path):
    wb = Workbook()
    ws = wb.active
    ws.title = "Сводка"
    ws2 = wb.create_sheet("Заказы")
    ws2.append(["Заказы интернет-магазина"])
    ws2.append([])
    ws2.append(["Дата", "Чек", "Позиция", "Артикул", "Товар", "Кол-во", "Сумма"])
    ws2.append(["01.10.2026", 7, 1, "pl-1001", "Плед", 1, 2790])
    ws2.append(["Всего", None, None, None, None, 1, 2790])
    wb.save(tmp_path / "site.xlsx")
    raw = read_export(tmp_path / "site.xlsx", source(sheet="Заказы"))
    assert raw.rows == [(4, {"date": "01.10.2026", "receipt": 7, "line": 1, "sku": "pl-1001", "name": "Плед",
                             "qty": 1, "amount": 2790})]
    assert raw.stated_total == 2790
    with pytest.raises(ConfigError, match="нет листа «Продажи». Листы: Сводка, Заказы"):
        read_export(tmp_path / "site.xlsx", source(sheet="Продажи"))


def test_old_xls_is_explained(tmp_path):
    with pytest.raises(ConfigError, match="пересохраните в Excel как .xlsx"):
        read_export(write(tmp_path / "old.xls", "x"), source())


def test_find_files_skips_excel_lock_files(tmp_path):
    for name in ("tv_1.csv", "tv_2.csv", "~$tv_3.csv", "other.csv"):
        write(tmp_path / name, HEAD)
    assert [p.name for p in find_files(tmp_path, source(files="tv*.csv"))] == ["tv_1.csv", "tv_2.csv"]


def test_catalog(tmp_path):
    wb = Workbook()
    wb.active.append(["Артикул", "Наименование", "Категория", "Себестоимость"])
    wb.active.append(["pl1001", "Плед", "Текстиль", "1 200,50"])
    wb.active.append(["PL-1002", "Доска", None, 400])
    wb.save(tmp_path / "cat.xlsx")
    items = read_catalog(Catalog(tmp_path / "cat.xlsx"))
    assert items["PL-1001"] == {"name": "Плед", "category": "Текстиль", "cost": 1200.5}
    assert items["PL-1002"]["category"] == "Без категории"


def test_examples_are_read_as_is(result):
    files = {f.file: f for f in result.files}
    assert files["lefortovo_2026-10.csv"].stated_total == 2_399_787.0  # cp1251, строка «Итого»
    assert files["sayt_zakazy_oktyabr.xlsx"].rows == 990  # шапка в 4-й строке
