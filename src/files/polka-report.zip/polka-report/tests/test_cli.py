from datetime import datetime

import openpyxl
from conftest import ROOT

from polka_report.__main__ import run

CONFIG = str(ROOT / "polka.toml")
NOW = datetime(2026, 11, 3, 9, 0)


def test_examples_end_to_end(tmp_path, capsys):
    assert run(["--config", CONFIG, "--out", str(tmp_path)], now=NOW) == 0
    out = capsys.readouterr().out
    assert "Полка · продажи за октябрь 2026" in out
    assert "Прочитано 4 файла" in out
    assert "В отчёте 5\u00a0369 строк. Дубли: 147 · другой месяц: 105 · отменены: 68 · с ошибками: 2" in out
    assert "lefortovo_2026-10.csv, строка 1056: сумма «119O.00» — не число" in out
    assert "PL-9001 «Подарочная упаковка»" in out
    path = tmp_path / "Полка — продажи за октябрь 2026.xlsx"
    wb = openpyxl.load_workbook(path, data_only=True)
    assert wb["Сводка"]["B3"].value.endswith("отчёт собран 03.11.2026 в 09:00")


def test_month_can_be_chosen(tmp_path, capsys):
    assert run(["--config", CONFIG, "--out", str(tmp_path), "--month", "09.2026"], now=NOW) == 0
    assert (tmp_path / "Полка — продажи за сентябрь 2026.xlsx").is_file()
    assert "В отчёте 105 строк" in capsys.readouterr().out


def test_errors_are_short_and_in_russian(tmp_path, capsys):
    assert run(["--config", str(tmp_path / "nope.toml")]) == 2
    assert capsys.readouterr().err.startswith("Ошибка: Не нашёл файл настроек")
    assert run(["--config", CONFIG, "--month", "октябрь"]) == 2
    assert "Не понял месяц «октябрь». Пример: 2026-10" in capsys.readouterr().err
    assert run(["--config", CONFIG, "--in", str(tmp_path)]) == 2
    assert "Для «Тверская» нет файлов tverskaya*.csv" in capsys.readouterr().err
