from datetime import date, datetime

import pytest

from polka_report.parse import month_name, normalize_sku, parse_date, parse_month, parse_number, plural, rub


@pytest.mark.parametrize("text, value", [
    ("1290", 1290.0), ("1 290,50", 1290.5), ("1\u00a0290,50 ₽", 1290.5), ("1290.5", 1290.5),
    ("1.290,50", 1290.5), ("1,290.50", 1290.5), ("-2", -2.0), ("−350", -350.0), ("350 руб.", 350.0),
    ("0,5", 0.5), (",5", 0.5), (1290, 1290.0), (12.5, 12.5),
])
def test_numbers(text, value):
    assert parse_number(text) == value


@pytest.mark.parametrize("text", ["", "   ", None, "119O.00", "1.2.3", "abc", "12-3", True, float("nan")])
def test_not_numbers(text):
    assert parse_number(text) is None


@pytest.mark.parametrize("value, expected", [
    ("01.10.2026", date(2026, 10, 1)), ("01.10.26 10:15", date(2026, 10, 1)),
    ("2026-10-01 10:15:03", date(2026, 10, 1)), ("01/10/2026", date(2026, 10, 1)),
    (datetime(2026, 10, 1, 23, 59), date(2026, 10, 1)), (date(2026, 10, 1), date(2026, 10, 1)),
    (46296, date(2026, 10, 1)),  # номер дня Excel
])
def test_dates(value, expected):
    assert parse_date(value) == expected


@pytest.mark.parametrize("value", ["", None, "32.10.2026", "вчера", 0, -5])
def test_bad_dates(value):
    assert parse_date(value) is None


@pytest.mark.parametrize("value, sku", [
    ("PL-1001", "PL-1001"), (" pl-1001 ", "PL-1001"), ("PL1001", "PL-1001"), ("pl 1001", "PL-1001"),
    ("Х-77", "Х-77"), (12345.0, "12345"), ("ABC/7", "ABC/7"), (None, ""),
])
def test_sku(value, sku):
    assert normalize_sku(value) == sku


def test_month():
    assert parse_month("2026-10") == (2026, 10)
    assert parse_month("10.2026") == (2026, 10)
    assert month_name((2026, 10)) == "октябрь 2026"
    with pytest.raises(ValueError, match="Пример: 2026-10"):
        parse_month("октябрь")


@pytest.mark.parametrize("n, word", [(1, "строка"), (2, "строки"), (5, "строк"), (11, "строк"), (21, "строка"),
                                     (104, "строки"), (112, "строк"), (0, "строк")])
def test_plural(n, word):
    assert plural(n, "строка", "строки", "строк") == word


def test_rub():
    assert rub(5734120.4) == "5\u00a0734\u00a0120\u00a0₽"
