from datetime import date

import pandas as pd
import pytest
from conftest import raw, rec, source

from polka_report.clean import NO_CATEGORY, RETURN, SALE, build
from polka_report.config import ConfigError

CATALOG = {"PL-1001": {"name": "Плед вязаный", "category": "Текстиль", "cost": 60.0},
           "PL-1002": {"name": "Доска", "category": "Кухня", "cost": 30.0}}
OPS = {"columns": {"date": "Дата", "receipt": "Чек", "line": "Позиция", "sku": "Артикул", "qty": "Кол-во",
                   "amount": "Сумма", "operation": "Операция"},
       "sales": ("продажа",), "returns": ("возврат",), "skip": ("отменён",)}


def counted(st):
    return st.in_report + st.duplicates + st.outside + st.cancelled + st.errors


def test_overlapping_exports_are_deduplicated():
    src = source()
    a = raw("tv_01-15.csv", src, rec(receipt="1"), rec(receipt="2"), rec(receipt="3", date="15.10.2026"))
    b = raw("tv_14-31.csv", src, rec(receipt="3", date="15.10.2026"), rec(receipt="4", date="16.10.2026"))
    res = build([a, b], CATALOG)
    assert len(res.rows) == 4
    assert [(f.in_report, f.duplicates, f.other_amount) for f in res.files] == [(3, 0, 0.0), (1, 1, 100.0)]


def test_same_item_twice_in_one_receipt_is_not_a_duplicate():
    res = build([raw("a.csv", source(), rec(line="1"), rec(line="2"))], CATALOG)
    assert len(res.rows) == 2 and res.files[0].duplicates == 0


def test_without_line_numbers_only_repeats_from_another_file_are_duplicates():
    cols = {"date": "Дата", "receipt": "Чек", "sku": "Артикул", "qty": "Кол-во", "amount": "Сумма"}
    src = source(columns=cols)
    mug = {k: v for k, v in rec().items() if k in cols}
    res = build([raw("a.xlsx", src, mug, mug), raw("b.xlsx", src, mug, mug, mug)], CATALOG)
    assert [(f.in_report, f.duplicates) for f in res.files] == [(2, 0), (1, 2)]


def test_returns_by_operation_are_negative():
    src = source(**OPS)
    res = build([raw("a.csv", src, rec(amount="100", operation="Продажа"),
                     rec(receipt="102", amount="100", operation="ВОЗВРАТ"))], CATALOG)
    sale, ret = res.rows.itertuples()
    assert (sale.kind, sale.qty, sale.amount) == (SALE, 1, 100)
    assert (ret.kind, ret.qty, ret.amount) == (RETURN, -1, -100)
    assert ret.profit == -100 + 60  # возврат уменьшает и выручку, и себестоимость


def test_returns_by_minus_sign_without_operation():
    res = build([raw("a.csv", source(), rec(qty="-1", amount="-100"), rec(receipt="102"))], CATALOG)
    assert list(res.rows.kind) == [RETURN, SALE]


def test_cancelled_orders_are_counted_but_not_in_report():
    src = source(**OPS)
    cancelled = rec(receipt="102", amount="500", operation="Отменён")
    res = build([raw("site.xlsx", src, rec(operation="Продажа"), cancelled)], CATALOG)
    st = res.files[0]
    assert (len(res.rows), st.cancelled, st.other_amount) == (1, 1, 500)


def test_unknown_operation_is_an_error_with_hint():
    res = build([raw("a.csv", source(**OPS), rec(operation="Обмен"))], CATALOG, month=(2026, 10))
    assert res.issues[0].reason == "неизвестная операция «Обмен» — добавьте её в [source.operations]"


def test_month_is_detected_and_other_months_are_set_aside():
    rows = [rec(receipt=str(i), date="30.09.2026") for i in range(3)] + [rec(receipt=str(i)) for i in range(10, 15)]
    res = build([raw("a.csv", source(), *rows)], CATALOG)
    assert res.month == (2026, 10)
    assert (len(res.rows), res.files[0].outside) == (5, 3)
    sept = build([raw("a.csv", source(), *rows)], CATALOG, month=(2026, 9))
    assert len(sept.rows) == 3 and set(sept.rows.date) == {date(2026, 9, 30)}


@pytest.mark.parametrize("record, reason", [
    (rec(date=""), "нет даты"),
    (rec(date="31.02.2026"), "дата «31.02.2026» не распознана"),
    (rec(receipt=" "), "нет номера чека"),
    (rec(sku=None), "нет артикула"),
    (rec(qty="один"), "количество «один» — не число"),
    (rec(amount="119O.00"), "сумма «119O.00» — не число"),
    (rec(amount=""), "нет суммы"),
])
def test_bad_rows_are_reported_with_file_row_and_reason(record, reason):
    res = build([raw("kassa.csv", source(), rec(), record)], CATALOG)
    issue, = res.issues
    assert (issue.file, issue.row, issue.reason) == ("kassa.csv", 3, reason)
    assert res.files[0].errors == 1 and len(res.rows) == 1


def test_catalog_join_and_unknown_items():
    res = build([raw("a.csv", source(), rec(sku="pl1001", name="ПЛЕД"), rec(receipt="2", sku="PL-9001", name="Пакет",
                                                                        amount="15"))], CATALOG)
    known, gift = res.rows.itertuples()
    assert (known.sku, known.name, known.category, known.cost, known.profit) == ("PL-1001", "Плед вязаный", "Текстиль",
                                                                                  60.0, 40.0)
    assert gift.category == NO_CATEGORY and pd.isna(gift.profit) and pd.isna(gift.cost)
    assert res.unknown.to_dict("records") == [{"sku": "PL-9001", "name": "Пакет", "rows": 1, "amount": 15.0}]


def test_receipts_are_counted_once_and_returns_do_not_count():
    src = source(**OPS)
    res = build([raw("a.csv", src, rec(receipt="1", line="2", operation="Продажа"),
                     rec(receipt="1", line="1", sku="PL-1002", operation="Продажа"),
                     rec(receipt="2", operation="Возврат"))], CATALOG)
    assert res.rows.new_receipt.tolist() == [1, 0, 0]  # строки отсортированы: чек 1 строка 1 — первая
    assert res.rows.line.tolist() == ["1", "2", "1"]


def test_nothing_to_count():
    with pytest.raises(ConfigError, match="нет ни одной строки"):
        build([raw("a.csv", source(), rec(date=""))], CATALOG)


def test_examples_every_row_is_accounted_for(result):
    for st in result.files:
        assert counted(st) == st.rows, st.file
    by_file = {f.file: f for f in result.files}
    assert by_file["tverskaya_14-31.10.csv"].duplicates > 0  # выгрузки Тверской пересекаются 14–15 октября
    assert by_file["lefortovo_2026-10.csv"].outside > 0  # в выгрузку попали 29–30 сентября
    assert by_file["sayt_zakazy_oktyabr.xlsx"].cancelled > 0
    assert {(i.file, i.row) for i in result.issues} == {("lefortovo_2026-10.csv", 1056),
                                                        ("sayt_zakazy_oktyabr.xlsx", 694)}


def test_examples_reconcile_with_totals_in_files(result):
    lef = next(f for f in result.files if f.stated_total is not None)
    broken = 1190.0  # строка с суммой «119O.00» — итог кассы её учёл, отчёт не смог
    assert lef.stated_total == pytest.approx(lef.report_amount + lef.other_amount + broken)
