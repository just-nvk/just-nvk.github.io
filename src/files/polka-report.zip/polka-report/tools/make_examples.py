"""Генерирует примеры выгрузок «Полки» за октябрь 2026: python tools/make_examples.py

Цифры вымышлены, но выгрузки устроены как настоящие: у каждой кассы свой формат, кодировка и ошибки.
Генератор детерминированный (seed), поэтому примеры и тесты всегда совпадают.
"""
from __future__ import annotations

import csv
import random
from datetime import date, datetime, timedelta
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Font

ROOT = Path(__file__).resolve().parent.parent / "examples"
CATALOG = [  # артикул, название, категория, цена
    ("PL-1001", "Набор ножей «Шеф», 3 шт", "Кухня", 3490), ("PL-1002", "Доска разделочная, бук", "Кухня", 890),
    ("PL-1003", "Сковорода чугунная 28 см", "Кухня", 2990), ("PL-1004", "Кружка керамическая 350 мл", "Кухня", 490),
    ("PL-1005", "Набор контейнеров, 5 шт", "Кухня", 1290), ("PL-1006", "Чайник заварочный 800 мл", "Кухня", 1190),
    ("PL-1007", "Френч-пресс 600 мл", "Кухня", 1490), ("PL-2001", "Корзина плетёная, большая", "Хранение", 1990),
    ("PL-2002", "Короб с крышкой", "Хранение", 790), ("PL-2003", "Органайзер для ящика", "Хранение", 590),
    ("PL-2004", "Вешалки бархатные, 10 шт", "Хранение", 690), ("PL-2005", "Банка для круп 1,5 л", "Хранение", 450),
    ("PL-2006", "Полка навесная, дуб", "Хранение", 2490), ("PL-3001", "Плед вязаный 130×170", "Текстиль", 2790),
    ("PL-3002", "Наволочка льняная 50×70", "Текстиль", 690),
    ("PL-3003", "Скатерть хлопковая 140×180", "Текстиль", 1590),
    ("PL-3004", "Полотенце банное 70×140", "Текстиль", 990), ("PL-3005", "Постельное бельё, евро", "Текстиль", 4990),
    ("PL-3006", "Подушка декоративная 45×45", "Текстиль", 1290),
    ("PL-4001", "Дозатор для мыла, керамика", "Ванная", 690),
    ("PL-4002", "Коврик для ванной", "Ванная", 1190), ("PL-4003", "Набор для ванной, 4 предмета", "Ванная", 1990),
    ("PL-4004", "Штора для душа", "Ванная", 1490), ("PL-5001", "Швабра с отжимом", "Уборка", 1890),
    ("PL-5002", "Салфетки из микрофибры, 5 шт", "Уборка", 390), ("PL-5003", "Щётка для посуды, бамбук", "Уборка", 250),
    ("PL-5004", "Ведро складное 10 л", "Уборка", 790), ("PL-6001", "Свеча ароматическая «Хвоя»", "Декор", 890),
    ("PL-6002", "Ваза стеклянная 25 см", "Декор", 1390), ("PL-6003", "Рамка для фото 21×30", "Декор", 590),
    ("PL-6004", "Гирлянда «Тёплый свет», 5 м", "Декор", 1190),
    ("PL-6005", "Диффузор ароматический 100 мл", "Декор", 1290),
]
GIFT = ("PL-9001", "Подарочная упаковка", 150)  # нет в справочнике — отчёт это покажет
YEAR, MONTH = 2026, 10


def weights(day: date):
    promo = 16 <= day.day <= 18 and day.month == MONTH  # распродажа текстиля
    out = []
    for sku, _, cat, price in CATALOG:
        w = (2400 / price) ** 0.8
        if sku in ("PL-3005", "PL-3001", "PL-1001", "PL-2001"):
            w *= 2.2  # хиты: дорогие и популярные
        if promo and cat == "Текстиль":
            w *= 2.6
        out.append(w)
    return out


def receipts(rng: random.Random, day: date, base: float, weekend: float):
    k = weekend if day.weekday() >= 5 else 1.0
    n = max(5, round(rng.gauss(base * k, base * 0.12)))
    out = []
    for _ in range(n):
        lines = rng.choices([1, 2, 3, 4], [55, 28, 12, 5])[0]
        items = rng.choices(CATALOG, weights(day), k=lines)
        t = datetime(day.year, day.month, day.day, rng.randint(10, 21), rng.randint(0, 59), rng.randint(0, 59))
        qty = [(it, rng.choices([1, 2, 3], [82, 14, 4])[0] if it[3] < 1000 else 1) for it in dict.fromkeys(items)]
        out.append((t, qty))
    return sorted(out, key=lambda x: x[0])  # номера чеков растут вместе со временем


def tverskaya(rng: random.Random):
    """Касса «А»: UTF-8, «;», запятая в дробях, возврат — отдельная операция. Выгружают двумя файлами внахлёст."""
    rows, no = [], 41000
    day = date(YEAR, MONTH, 1)
    while day.month == MONTH:
        for t, items in receipts(rng, day, 46, 1.35):
            no += 1
            disc = 0.95 if rng.random() < 0.18 else 1.0  # карта постоянного покупателя
            for pos, (it, qty) in enumerate(items, 1):
                rows.append([t.strftime("%d.%m.%Y"), t.strftime("%H:%M"), f"Т-{no}", pos, it[0], it[1], qty,
                             f"{it[3]:.2f}".replace(".", ","), f"{round(it[3] * qty * disc, 2):.2f}".replace(".", ","),
                             "Продажа"])
            if rng.random() < 0.015:  # возврат одной позиции
                it, qty = items[0]
                no += 1
                rows.append([t.strftime("%d.%m.%Y"), "20:4" + str(rng.randint(0, 9)), f"Т-{no}", 1, it[0], it[1], qty,
                             f"{it[3]:.2f}".replace(".", ","), f"{it[3] * qty:.2f}".replace(".", ","), "Возврат"])
        day += timedelta(days=1)
    head = ["Дата", "Время", "Чек", "Позиция", "Артикул", "Товар", "Кол-во", "Цена", "Сумма", "Операция"]
    first = [r for r in rows if int(r[0][:2]) <= 15]
    second = [r for r in rows if int(r[0][:2]) >= 14]  # 14 и 15 октября — в обоих файлах
    for name, part in (("tverskaya_01-15.10.csv", first), ("tverskaya_14-31.10.csv", second)):
        with open(ROOT / "exports" / name, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.writer(f, delimiter=";")
            w.writerow(head)
            w.writerows(part)


def ascii_name(name: str) -> str:
    """Старая касса хранит названия по-своему: без «ёлочек» и знака ×."""
    return name.replace("×", "x").replace("«", '"').replace("»", '"').upper()


def lefortovo(rng: random.Random):
    """Касса «Б»: Windows-1251, запятая-разделитель, точка в дробях, возврат — минус. В конце строка «Итого».
    В выгрузку попали 29–30 сентября, а в одной строке сумма набрана с буквой «О» вместо нуля."""
    rows, no, total = [], 7800, 0.0
    day = date(YEAR, MONTH - 1, 29)
    while day.month <= MONTH:
        for t, items in receipts(rng, day, 34, 1.4):
            no += 1
            for pos, (it, qty) in enumerate(items, 1):
                disc = round(it[3] * qty * 0.1, 2) if rng.random() < 0.08 else 0.0
                amount = round(it[3] * qty - disc, 2)
                rows.append([t.strftime("%Y-%m-%d %H:%M:%S"), no, pos, it[0], ascii_name(it[1]), qty, f"{it[3]:.2f}",
                             f"{disc:.2f}", f"{amount:.2f}"])
                total += amount
            if rng.random() < 0.02:
                it, qty = items[-1]
                rows.append([(t + timedelta(minutes=40)).strftime("%Y-%m-%d %H:%M:%S"), no, len(items) + 1, it[0],
                             ascii_name(it[1]), -qty, f"{it[3]:.2f}", "0.00", f"{-it[3] * qty:.2f}"])
                total -= it[3] * qty
        day += timedelta(days=1)
    broken = next(i for i, r in enumerate(rows) if r[0].startswith("2026-10-17") and r[8] == "1190.00")
    rows[broken][8] = "119O.00"  # опечатка в кассе: буква О вместо нуля
    with open(ROOT / "exports" / "lefortovo_2026-10.csv", "w", encoding="cp1251", newline="") as f:
        w = csv.writer(f, delimiter=",")
        w.writerow(["date", "check_no", "line", "sku", "name", "qty", "price", "discount", "total"])
        w.writerows(rows)
        w.writerow(["Итого", "", "", "", "", "", "", "", f"{total:.2f}"])


def site(rng: random.Random):
    """Сайт: Excel из CMS — шапка не в первой строке, статусы заказов, часть сумм вбита текстом."""
    wb = Workbook()
    ws = wb.active
    ws.title = "Заказы"
    ws["A1"] = "Заказы интернет-магазина «Полка»"
    ws["A1"].font = Font(bold=True, size=13)
    ws["A2"] = "Период: 01.10.2026 — 31.10.2026"
    ws.append([])
    ws.append(["№ заказа", "Дата заказа", "Артикул", "Наименование", "Кол-во", "Цена, ₽", "Скидка, ₽", "Сумма, ₽",
               "Статус", "Город"])
    for c in ws[4]:
        c.font = Font(bold=True)
    no = 10200
    day = date(YEAR, MONTH, 1)
    cities = ["Москва"] * 6 + ["Химки", "Мытищи", "Люберцы", "Красногорск"]
    while day.month == MONTH:
        base = 22 if day.weekday() == 0 else 18
        for t, items in receipts(rng, day, base, 0.85):
            no += 1
            status = rng.choices(["Доставлен", "Отменён", "Возврат"], [91, 6, 3])[0]
            if rng.random() < 0.09:
                items = items + [(GIFT, 1)]
            city = rng.choice(cities)
            for it, qty in items:
                sku, name, price = (it[0], it[1], it[3]) if len(it) == 4 else it
                disc = round(price * qty * 0.07) if rng.random() < 0.1 else 0
                amount = price * qty - disc
                if rng.random() < 0.03:
                    sku = " " + sku.lower()
                value = f"{amount:,} ₽".replace(",", " ") if rng.random() < 0.03 else amount
                ws.append([f"S-{no}", t, sku, name, qty, price, disc, value, status, city])
        day += timedelta(days=1)
    ws.cell(row=ws.max_row - 300, column=2).value = None  # заказ без даты
    for row in ws.iter_rows(min_row=5, min_col=2, max_col=2):
        row[0].number_format = "DD.MM.YYYY HH:MM"
    for col, w in zip("ABCDEFGHIJ", [11, 17, 10, 34, 8, 9, 10, 11, 11, 12], strict=True):
        ws.column_dimensions[col].width = w
    wb.save(ROOT / "exports" / "sayt_zakazy_oktyabr.xlsx")


def catalog(rng: random.Random):
    wb = Workbook()
    ws = wb.active
    ws.title = "Товары"
    ws.append(["Артикул", "Наименование", "Категория", "Себестоимость", "Цена"])
    for c in ws[1]:
        c.font = Font(bold=True)
    for sku, name, cat, price in CATALOG:
        ws.append([sku, name, cat, round(price * rng.uniform(0.42, 0.6)), price])
    for col, w in zip("ABCDE", [10, 34, 12, 14, 9], strict=True):
        ws.column_dimensions[col].width = w
    wb.save(ROOT / "catalog.xlsx")


if __name__ == "__main__":
    (ROOT / "exports").mkdir(parents=True, exist_ok=True)
    rng = random.Random(2026)
    catalog(rng)
    tverskaya(rng)
    lefortovo(rng)
    site(rng)
    print("Готово:", ", ".join(sorted(p.name for p in (ROOT / "exports").iterdir())))
