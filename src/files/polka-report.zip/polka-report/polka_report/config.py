"""Настройки отчёта из polka.toml: источники, колонки выгрузок, справочник товаров."""
from __future__ import annotations

import tomllib
from dataclasses import dataclass, field
from pathlib import Path

# Поля, которые отчёт берёт из каждой выгрузки. Обязательные — без них строку не посчитать.
FIELDS = {
    "date": "дата",
    "receipt": "номер чека или заказа",
    "line": "номер строки в чеке",
    "sku": "артикул",
    "name": "название товара",
    "qty": "количество",
    "amount": "сумма",
    "operation": "операция или статус",
}
REQUIRED = ("date", "receipt", "sku", "qty", "amount")


class ConfigError(Exception):
    """Ошибка в настройках или во входных файлах — текст показывается пользователю как есть."""


@dataclass(frozen=True)
class Source:
    name: str
    files: str
    columns: dict[str, str]
    sales: tuple[str, ...] = ()
    returns: tuple[str, ...] = ()
    skip: tuple[str, ...] = ()
    encoding: str | None = None
    delimiter: str | None = None
    sheet: str | None = None


@dataclass(frozen=True)
class Catalog:
    file: Path
    columns: dict[str, str] = field(default_factory=lambda: {
        "sku": "Артикул", "name": "Наименование", "category": "Категория", "cost": "Себестоимость"})


@dataclass(frozen=True)
class Config:
    company: str
    exports: Path
    reports: Path
    catalog: Catalog
    sources: tuple[Source, ...]
    abc_a: float = 0.80
    abc_b: float = 0.95


def _words(value) -> tuple[str, ...]:
    if value is None:
        return ()
    if isinstance(value, str):
        value = [value]
    return tuple(str(v).strip().lower() for v in value)


def load(path: Path) -> Config:
    path = Path(path)
    if not path.is_file():
        raise ConfigError(f"Не нашёл файл настроек {path}")
    try:
        raw = tomllib.loads(path.read_text(encoding="utf-8"))
    except tomllib.TOMLDecodeError as e:
        raise ConfigError(f"Ошибка в {path.name}: {e}") from None
    base = path.parent

    sources = []
    for i, s in enumerate(raw.get("source", []), 1):
        name = s.get("name") or f"Источник {i}"
        columns = {k: str(v) for k, v in (s.get("columns") or {}).items()}
        unknown = sorted(set(columns) - set(FIELDS))
        if unknown:
            raise ConfigError(f"«{name}»: неизвестные поля в [source.columns]: {', '.join(unknown)}. "
                              f"Возможные: {', '.join(FIELDS)}")
        missing = [f for f in REQUIRED if f not in columns]
        if missing:
            raise ConfigError(f"«{name}»: в [source.columns] не указаны колонки для полей: "
                              + ", ".join(f"{f} ({FIELDS[f]})" for f in missing))
        if not s.get("files"):
            raise ConfigError(f"«{name}»: не указано, какие файлы читать (files = \"…\")")
        ops = s.get("operations") or {}
        sources.append(Source(name=name, files=s["files"], columns=columns, sales=_words(ops.get("sale")),
                              returns=_words(ops.get("return")), skip=_words(ops.get("skip")),
                              encoding=s.get("encoding"), delimiter=s.get("delimiter"), sheet=s.get("sheet")))
    if not sources:
        raise ConfigError(f"В {path.name} нет ни одного источника [[source]]")
    names = [s.name for s in sources]
    if len(set(names)) != len(names):
        raise ConfigError("Названия источников повторяются — у каждого [[source]] должно быть своё name")

    cat = raw.get("catalog") or {}
    if not cat.get("file"):
        raise ConfigError(f"В {path.name} не указан справочник товаров: [catalog] file = \"…\"")
    catalog = Catalog(file=base / cat["file"], columns={**Catalog(Path()).columns, **(cat.get("columns") or {})})

    abc = raw.get("abc") or {}
    a, b = float(abc.get("a", 0.80)), float(abc.get("b", 0.95))
    if not 0 < a < b <= 1:
        raise ConfigError("Пороги ABC должны идти по возрастанию от 0 до 1, например a = 0.8, b = 0.95")

    return Config(company=raw.get("company", "Компания"), exports=base / raw.get("exports", "exports"),
                  reports=base / raw.get("reports", "reports"), catalog=catalog, sources=tuple(sources),
                  abc_a=a, abc_b=b)
