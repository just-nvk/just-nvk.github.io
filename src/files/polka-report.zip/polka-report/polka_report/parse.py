"""Разбор значений из выгрузок: числа, даты, артикулы. Чистые функции без pandas."""
from __future__ import annotations

import re
from datetime import date, datetime, timedelta

_SPACES = re.compile(r"[\s\u00a0\u202f\u2009']")
_CURRENCY = re.compile(r"(₽|руб\.?|р\.)$", re.IGNORECASE)
_NUMBER = re.compile(r"^[+-]?(\d+([.,]\d*)?|[.,]\d+)$")
_SKU = re.compile(r"^([A-ZА-Я]+)-?(\d+)$")
_EXCEL_EPOCH = datetime(1899, 12, 30)

MONTHS = ["январь", "февраль", "март", "апрель", "май", "июнь",
          "июль", "август", "сентябрь", "октябрь", "ноябрь", "декабрь"]


def is_blank(value) -> bool:
    if value is None:
        return True
    if isinstance(value, float) and value != value:  # NaN из pandas
        return True
    return isinstance(value, str) and not value.strip()


def parse_number(value) -> float | None:
    """«1 290,50 ₽», «1290.5», «-2», 1290 → число; мусор → None.

    Запятая — десятичный разделитель (так пишут кассы в России). Если в строке есть и точка,
    и запятая, десятичный — последний из них: «1.290,50» и «1,290.50» дают 1290.5.
    """
    if is_blank(value) or isinstance(value, bool):
        return None
    if isinstance(value, int | float):
        return float(value)
    s = _CURRENCY.sub("", str(value).strip()).strip()
    s = _SPACES.sub("", s).replace("−", "-")
    if "," in s and "." in s:
        dec = "," if s.rfind(",") > s.rfind(".") else "."
        s = s.replace("." if dec == "," else ",", "")
    if s.count(",") + s.count(".") > 1 or not _NUMBER.match(s):
        return None
    return float(s.replace(",", "."))


def parse_date(value) -> date | None:
    """Дата из выгрузки: datetime из Excel, номер дня Excel, «01.10.2026», «01.10.26 10:15», «2026-10-01 10:15:03»."""
    if is_blank(value) or isinstance(value, bool):
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if isinstance(value, int | float):
        return (_EXCEL_EPOCH + timedelta(days=float(value))).date() if 1 <= value < 200_000 else None
    s = str(value).strip().split()[0].rstrip(",")
    for fmt in ("%d.%m.%Y", "%Y-%m-%d", "%d.%m.%y", "%d/%m/%Y"):
        try:
            return datetime.strptime(s, fmt).date()
        except ValueError:
            pass
    return None


def normalize_sku(value) -> str:
    """« pl-1001 », «PL1001», «PL-1001» → «PL-1001». Нестандартный артикул возвращается как есть, без пробелов."""
    if is_blank(value):
        return ""
    if isinstance(value, float) and value.is_integer():
        value = int(value)
    s = _SPACES.sub("", str(value)).upper()
    m = _SKU.match(s)
    return f"{m.group(1)}-{m.group(2)}" if m else s


def clean_text(value) -> str:
    if is_blank(value):
        return ""
    if isinstance(value, float) and value.is_integer():
        value = int(value)
    return " ".join(str(value).split())


def month_name(month: tuple[int, int]) -> str:
    """(2026, 10) → «октябрь 2026»."""
    year, m = month
    return f"{MONTHS[m - 1]} {year}"


def parse_month(text: str) -> tuple[int, int]:
    """«2026-10» или «10.2026» → (2026, 10)."""
    s = text.strip()
    for fmt in ("%Y-%m", "%m.%Y", "%m/%Y"):
        try:
            d = datetime.strptime(s, fmt)
            return d.year, d.month
        except ValueError:
            pass
    raise ValueError(f"Не понял месяц «{text}». Пример: 2026-10")


def plural(n: int, one: str, few: str, many: str) -> str:
    """plural(3, 'строка', 'строки', 'строк') → «строки»."""
    n = abs(n) % 100
    if 11 <= n <= 14:
        return many
    n %= 10
    return one if n == 1 else few if 2 <= n <= 4 else many


def rub(x: float) -> str:
    """5734120.4 → «5 734 120 ₽» (для вывода в терминал)."""
    return f"{round(x):,}".replace(",", "\u00a0") + "\u00a0₽"


def num(n: int) -> str:
    return f"{n:,}".replace(",", "\u00a0")
