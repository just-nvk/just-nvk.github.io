"""Excel-отчёт: сводка, дни, товары, сверка и все строки продаж.

Все итоги — формулы Excel по умной таблице «Продажи» на листе «Данные»: любую цифру можно проверить,
кликнув по ячейке. Рядом с формулой записано готовое значение, посчитанное в pandas, — поэтому файл
сразу показывает числа даже там, где формулы не пересчитываются (превью в почте и мессенджерах).
"""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

import xlsxwriter
from xlsxwriter.utility import xl_rowcol_to_cell

from .aggregate import Report, aggregate
from .clean import RETURN, SALE, Result
from .parse import month_name

FONT = "Arial"
INK, MUTED, LINE, CARD, HEAD = "#1F2328", "#6B7280", "#E3E2DC", "#F4F3EF", "#ECEEE9"
GOOD, WARN, BAD = "#DCEBDD", "#F8E7BF", "#F6D5D1"
STORE_COLORS = ["#2F5D50", "#D9A441", "#7C9CBF", "#B5838D", "#6D597A", "#8AA37B"]
T = "Продажи"  # умная таблица на листе «Данные»; формулы ссылаются на её колонки: Продажи[Сумма]

MONEY, MONEY2, PCT, INT, DATE = '#,##0 "₽"', "#,##0.00", "0.0%", "#,##0", "dd.mm.yyyy"
DATA_HEADERS = ["Дата", "Магазин", "Чек", "Строка", "Артикул", "Товар", "Категория", "Операция", "Количество",
                "Сумма", "Себестоимость", "Прибыль", "Чеков", "Файл", "Строка файла"]
STATUS_OK = "Сходится"
BADGE_OK, BADGE_WARN = "✓ Все строки учтены, итоги сходятся", "! Есть замечания — лист «Проверки»"


def file_status(st) -> str:
    """Статус сверки файла — та же логика, что в формуле колонки «Статус» на листе «Проверки»."""
    if st.in_report + st.duplicates + st.outside + st.cancelled + st.errors != st.rows:
        return "Потеряны строки"
    if st.errors:
        return "Есть строки с ошибками"
    if st.stated_total is None:
        return "Сходится (итога в файле нет)"
    return STATUS_OK if abs(st.stated_total - st.report_amount - st.other_amount) < 0.01 else "Не сходится с итогом"


def report_name(company: str, month: tuple[int, int]) -> str:
    return f"{company} — продажи за {month_name(month)}.xlsx"


class _Book:
    def __init__(self, path: Path, cached: bool):
        self.wb = xlsxwriter.Workbook(str(path), {"strings_to_numbers": False, "strings_to_formulas": False,
                                                  "strings_to_urls": False})
        self.cached = cached
        self._formats: dict = {}

    def f(self, **props):
        key = tuple(sorted(props.items()))
        if key not in self._formats:
            base = {"font_name": FONT, "font_size": 10, "font_color": INK, "valign": "vcenter"}
            self._formats[key] = self.wb.add_format({**base, **props})
        return self._formats[key]

    def formula(self, ws, row: int, col: int, formula: str, fmt, value):
        """Формула и её значение. cached=False пишет 0 — так тесты проверяют, что формулы считают сами."""
        if isinstance(value, float):
            value = round(value, 10) + 0.0  # без «-0»
        ws.write_formula(row, col, formula, fmt, value if self.cached else 0)


def _col(c: int) -> str:
    return xl_rowcol_to_cell(0, c)[:-1]


def _q(text: str) -> str:
    return '"' + text.replace('"', '""') + '"'


def _print_wide(ws, repeat_header: bool = True) -> None:
    """Альбомная печать на всю ширину листа, шапка таблицы — на каждой странице."""
    ws.set_landscape()
    ws.set_paper(9)
    ws.fit_to_pages(1, 0)
    ws.set_margins(left=0.4, right=0.4, top=0.5, bottom=0.5)
    if repeat_header:
        ws.repeat_rows(0)


# ---------- лист «Данные» ----------
def _data_sheet(b: _Book, ws, rows) -> None:
    n = len(rows)
    hdr = b.f(bold=True, bg_color=HEAD, bottom=1, bottom_color=LINE)
    ws.add_table(0, 0, max(n, 1), len(DATA_HEADERS) - 1, {
        "name": T, "style": "Table Style Light 1",
        "columns": [{"header": h, "header_format": hdr} for h in DATA_HEADERS]})
    fdate, ftext, fqty, fmoney, fint = b.f(num_format=DATE, align="left"), b.f(), b.f(num_format=INT), \
        b.f(num_format=MONEY2), b.f(num_format="0")
    for i, r in enumerate(rows.itertuples(index=False), 1):
        x = i + 1  # номер строки в Excel
        ws.write_datetime(i, 0, datetime(r.date.year, r.date.month, r.date.day), fdate)
        for c, v in ((1, r.source), (2, r.receipt), (4, r.sku), (5, r.name), (6, r.category), (7, r.kind)):
            ws.write_string(i, c, v, ftext)
        if r.line.isdigit():
            ws.write_number(i, 3, int(r.line), fint)
        else:
            ws.write_string(i, 3, r.line, ftext)
        ws.write_number(i, 8, r.qty, fqty)
        ws.write_number(i, 9, r.amount, fmoney)
        if r.cost is None or r.cost != r.cost:
            ws.write_blank(i, 10, None, fmoney)
        else:
            ws.write_number(i, 10, r.cost, fmoney)
        profit = "" if r.profit is None or r.profit != r.profit else r.profit
        b.formula(ws, i, 11, f'=IF(K{x}="","",J{x}-I{x}*K{x})', fmoney, profit)
        ws.write_number(i, 12, r.new_receipt, fint)
        ws.write_string(i, 13, r.file, ftext)
        ws.write_number(i, 14, r.file_row, fint)
    for c, w in enumerate([12, 13, 11, 10, 11, 40, 14, 12, 14, 12, 17, 12, 10, 30, 15]):  # с запасом под кнопки фильтра
        ws.set_column(c, c, w)
    ws.freeze_panes(1, 0)
    # номер чека — идентификатор, а не число: «7872» и «Т-41001» хранятся одинаково, текстом
    ws.ignore_errors({"number_stored_as_text": f"C2:C{n + 1}"})
    ws.write_comment("M1", "1 — первая строка чека продажи. Сумма колонки — число чеков.", {"x_scale": 1.6})
    ws.write_comment("K1", "Себестоимость за штуку из справочника товаров. Пусто — товара нет в справочнике.",
                     {"x_scale": 1.8})
    _print_wide(ws)


# ---------- лист «По дням» ----------
def _days_sheet(b: _Book, ws, rep: Report, stores: list[str]) -> None:
    hdr = b.f(bold=True, bg_color=HEAD, bottom=1, bottom_color=LINE, align="right")
    ws.write_string(0, 0, "Дата", b.f(bold=True, bg_color=HEAD, bottom=1, bottom_color=LINE))
    for j, s in enumerate(stores, 1):
        ws.write_string(0, j, s, hdr)
    tot_c = len(stores) + 1
    ws.write_string(0, tot_c, "Итого", hdr)
    fdate, fmoney, fbold = b.f(num_format=DATE, align="left"), b.f(num_format=MONEY), b.f(num_format=MONEY, bold=True)
    n = len(rep.days)
    for i, (d, values) in enumerate(rep.days.iterrows(), 1):
        ws.write_datetime(i, 0, datetime(d.year, d.month, d.day), fdate)
        for j, s in enumerate(stores, 1):
            ref = xl_rowcol_to_cell(0, j, row_abs=True)
            b.formula(ws, i, j, f"=SUMIFS({T}[Сумма],{T}[Дата],$A{i + 1},{T}[Магазин],{ref})", fmoney, float(values[s]))
        b.formula(ws, i, tot_c, f"=SUM(B{i + 1}:{_col(tot_c - 1)}{i + 1})", fbold, float(values.sum()))
    last = n + 1
    ftot, ftotm = b.f(bold=True, top=1, top_color=INK), b.f(bold=True, top=1, top_color=INK, num_format=MONEY)
    ws.write_string(last, 0, "Итого", ftot)
    for j in range(1, tot_c + 1):
        col = _col(j)
        value = float(rep.days.iloc[:, j - 1].sum()) if j < tot_c else float(rep.days.values.sum())
        b.formula(ws, last, j, f"=SUM({col}2:{col}{n + 1})", ftotm, value)
    ws.conditional_format(1, 0, n, tot_c, {"type": "formula", "criteria": "=WEEKDAY($A2,2)>5",
                                           "format": b.wb.add_format({"bg_color": CARD})})
    ws.set_column(0, 0, 12)
    ws.set_column(1, tot_c, 15)
    ws.freeze_panes(1, 1)
    ws.write_string(last + 2, 0, "Выходные выделены цветом.", b.f(font_color=MUTED, font_size=9))
    _print_wide(ws)


# ---------- лист «Товары» ----------
def _products_sheet(b: _Book, ws, rep: Report, abc_a: float, abc_b: float) -> None:
    heads = ["Артикул", "Товар", "Категория", "Продано, шт", "Возвращено, шт", "Выручка", "Прибыль", "Маржа",
             "Доля выручки", "Накопленная доля", "ABC"]
    for c, h in enumerate(heads):
        ws.write_string(0, c, h, b.f(bold=True, bg_color=HEAD, bottom=1, bottom_color=LINE,
                                     align="left" if c < 3 else "center" if c == 10 else "right", text_wrap=True))
    ws.set_row(0, 30)
    p = rep.products
    n = len(p)
    tot = n + 2  # строка «Итого» в Excel
    ftext, fint, fmoney, fpct = b.f(), b.f(num_format=INT), b.f(num_format=MONEY), b.f(num_format=PCT)
    fabc = b.f(align="center", bold=True)
    for i, r in enumerate(p.itertuples(index=False), 1):
        x = i + 1
        ws.write_string(i, 0, r.sku, ftext)
        ws.write_string(i, 1, r.name, ftext)
        ws.write_string(i, 2, r.category, ftext)
        crit = f"{T}[Артикул],$A{x}"
        b.formula(ws, i, 3, f'=SUMIFS({T}[Количество],{crit},{T}[Операция],"{SALE}")', fint, r.sold)
        b.formula(ws, i, 4, f'=-SUMIFS({T}[Количество],{crit},{T}[Операция],"{RETURN}")', fint, r.returned)
        b.formula(ws, i, 5, f"=SUMIFS({T}[Сумма],{crit})", fmoney, r.revenue)
        b.formula(ws, i, 6, f'=IF(COUNTIFS({crit},{T}[Себестоимость],"<>")=0,"",SUMIFS({T}[Прибыль],{crit}))',
                  fmoney, r.profit)
        b.formula(ws, i, 7, f'=IF(OR(G{x}="",F{x}<=0),"",G{x}/F{x})', fpct, r.margin)
        b.formula(ws, i, 8, f"=IF($F${tot}>0,F{x}/$F${tot},0)", fpct, r.share)
        b.formula(ws, i, 9, f"=SUM($I$2:I{x})", fpct, r.cum)
        b.formula(ws, i, 10, f'=IF(J{x}-I{x}<$N$2,"A",IF(J{x}-I{x}<$N$3,"B","C"))', fabc, r.abc)
    t = rep.total
    ftot = {"bold": True, "top": 1, "top_color": INK}
    ws.write_string(tot - 1, 0, "Итого", b.f(**ftot))
    for c in (1, 2):
        ws.write_blank(tot - 1, c, None, b.f(**ftot))
    sums = {3: float(p.sold.sum()), 4: float(p.returned.sum()), 5: float(p.revenue.sum()),
            6: float(sum(v for v in p.profit if v != ""))}
    for c, v in sums.items():
        col = _col(c)
        b.formula(ws, tot - 1, c, f"=SUM({col}2:{col}{tot - 1})", b.f(**ftot, num_format=INT if c < 5 else MONEY), v)
    b.formula(ws, tot - 1, 7, f'=IF(SUMIFS({T}[Сумма],{T}[Себестоимость],"<>")<>0,'
              f'G{tot}/SUMIFS({T}[Сумма],{T}[Себестоимость],"<>"),"")', b.f(**ftot, num_format=PCT), t.margin)
    b.formula(ws, tot - 1, 8, f"=SUM(I2:I{tot - 1})", b.f(**ftot, num_format=PCT), float(p.share.sum()) if n else 0.0)
    for c in (9, 10):
        ws.write_blank(tot - 1, c, None, b.f(**ftot))

    if n:
        rng = f"K2:K{tot - 1}"
        for cls, color in (("A", GOOD), ("B", WARN), ("C", CARD)):
            ws.conditional_format(rng, {"type": "cell", "criteria": "==", "value": f'"{cls}"',
                                        "format": b.wb.add_format({"bg_color": color})})
        ws.conditional_format(f"F2:F{tot - 1}", {"type": "data_bar", "bar_color": "#B9CDC4", "bar_solid": True,
                                                  "bar_no_border": True, "min_type": "num", "min_value": 0})
        ws.autofilter(0, 0, n, 10)

    # Пороги ABC — живые ячейки: поменяйте 80% на 70%, и классы пересчитаются.
    ws.write_string(0, 12, "ABC-анализ", b.f(bold=True))
    ws.write_string(1, 12, "A — до", ftext)
    ws.write_number(1, 13, abc_a, b.f(num_format="0%", bg_color=CARD, bold=True))
    ws.write_string(2, 12, "B — до", ftext)
    ws.write_number(2, 13, abc_b, b.f(num_format="0%", bg_color=CARD, bold=True))
    note = b.f(font_color=MUTED, font_size=9)
    for k, line in enumerate([f"A — товары, дающие первые {abc_a:.0%} выручки", f"B — следующие {abc_b - abc_a:.0%}",
                              f"C — остальные {1 - abc_b:.0%}", "Пороги можно менять —", "классы пересчитаются."]):
        ws.write_string(4 + k, 12, line, note)
    for c, w in enumerate([10, 40, 14, 11, 13, 13, 13, 9, 10, 12, 6, 2, 28, 8]):
        ws.set_column(c, c, w)
    ws.freeze_panes(1, 2)
    _print_wide(ws)


# ---------- лист «Проверки» ----------
def _checks_sheet(b: _Book, ws, result: Result) -> tuple[int, int]:
    ws.hide_gridlines(2)
    ws.write_string(0, 0, "Сверка с выгрузками", b.f(bold=True, font_size=14))
    ws.write_string(1, 0, "Каждая строка выгрузки — либо в отчёте, либо в одной из колонок «Дубли», «Другой месяц», "
                          "«Отменены», «С ошибками».", b.f(font_color=MUTED))
    heads = ["Файл", "Магазин", "Строк в файле", "В отчёте", "Дубли", "Другой месяц", "Отменены", "С ошибками",
             "Все строки учтены", "Сумма в отчёте", "Не вошло, ₽", "Итог в файле", "Разница", "Статус"]
    hr = 3
    for c, h in enumerate(heads):
        ws.write_string(hr, c, h, b.f(bold=True, bg_color=HEAD, bottom=1, bottom_color=LINE, text_wrap=True,
                                      align="left" if c in (0, 1, 13) else "right"))
    ws.set_row(hr, 30)
    ftext, fint, fmoney = b.f(bottom=1, bottom_color=LINE), b.f(num_format=INT, bottom=1, bottom_color=LINE), \
        b.f(num_format=MONEY2, bottom=1, bottom_color=LINE)
    first = hr + 1
    for i, st in enumerate(result.files):
        r, x = first + i, first + i + 1
        ws.write_string(r, 0, st.file, ftext)
        ws.write_string(r, 1, st.source, ftext)
        ws.write_number(r, 2, st.rows, fint)
        b.formula(ws, r, 3, f"=COUNTIFS({T}[Файл],$A{x})", fint, st.in_report)
        for c, v in ((4, st.duplicates), (5, st.outside), (6, st.cancelled), (7, st.errors)):
            ws.write_number(r, c, v, fint)
        counted = st.in_report + st.duplicates + st.outside + st.cancelled + st.errors
        b.formula(ws, r, 8, f'=IF(C{x}=SUM(D{x}:H{x}),"Да","Нет")', b.f(align="right", bottom=1, bottom_color=LINE),
                  "Да" if counted == st.rows else "Нет")
        b.formula(ws, r, 9, f"=SUMIFS({T}[Сумма],{T}[Файл],$A{x})", fmoney, st.report_amount)
        ws.write_number(r, 10, st.other_amount, fmoney)
        if st.stated_total is None:
            ws.write_blank(r, 11, None, fmoney)
            diff = ""
        else:
            ws.write_number(r, 11, st.stated_total, fmoney)
            diff = st.stated_total - (st.report_amount + st.other_amount)
        b.formula(ws, r, 12, f'=IF(L{x}="","",L{x}-(J{x}+K{x}))', fmoney, diff)
        b.formula(ws, r, 13, f'=IF(I{x}="Нет","Потеряны строки",IF(H{x}>0,"Есть строки с ошибками",'
                             f'IF(L{x}="","Сходится (итога в файле нет)",IF(ABS(M{x})<0.01,"{STATUS_OK}",'
                             f'"Не сходится с итогом"))))', ftext, file_status(st))
    last = first + len(result.files) - 1
    for crit, color in ((STATUS_OK, GOOD), ("Есть", WARN), ("Не", BAD), ("Потеряны", BAD)):
        ws.conditional_format(first, 13, last, 13, {"type": "text", "criteria": "begins with", "value": crit,
                                                    "format": b.wb.add_format({"bg_color": color})})
    ws.conditional_format(first, 8, last, 8, {"type": "cell", "criteria": "==", "value": '"Нет"',
                                              "format": b.wb.add_format({"bg_color": BAD})})

    sec = b.f(bold=True, font_size=11)
    r = last + 3
    ws.write_string(r, 0, "Строки с ошибками — в отчёт не вошли", sec)
    r += 1
    hdr = b.f(bold=True, bg_color=HEAD)
    plain, muted = b.f(), b.f(font_color=MUTED)
    if result.issues:
        ws.write_string(r, 0, "Файл", hdr)
        ws.write_string(r, 1, "Строка", hdr)
        ws.merge_range(r, 2, r, 5, "Что не так", hdr)
        ws.merge_range(r, 6, r, 13, "Содержимое строки", hdr)
        for issue in result.issues:
            r += 1
            ws.write_string(r, 0, issue.file, plain)
            ws.write_number(r, 1, issue.row, b.f(num_format=INT, align="left"))
            ws.merge_range(r, 2, r, 5, issue.reason, plain)
            ws.merge_range(r, 6, r, 13, issue.raw, muted)
    else:
        ws.write_string(r, 0, "Нет — все строки разобраны.", muted)

    r += 3
    ws.write_string(r, 0, "Товары не из справочника", sec)
    r += 1
    if len(result.unknown):
        ws.write_string(r, 0, "В выручке они учтены, но без себестоимости прибыль по ним не посчитать. "
                              "Добавьте их в справочник товаров.", muted)
        r += 1
        ws.write_string(r, 0, "Артикул", hdr)
        ws.merge_range(r, 1, r, 4, "Название в выгрузке", hdr)
        ws.write_string(r, 5, "Строк", b.f(bold=True, bg_color=HEAD, align="right"))
        ws.write_string(r, 6, "Сумма", b.f(bold=True, bg_color=HEAD, align="right"))
        for u in result.unknown.itertuples(index=False):
            r += 1
            ws.write_string(r, 0, u.sku, plain)
            ws.merge_range(r, 1, r, 4, u.name, plain)
            ws.write_number(r, 5, u.rows, b.f(num_format=INT))
            ws.write_number(r, 6, round(u.amount, 2), b.f(num_format=MONEY2))
    else:
        ws.write_string(r, 0, "Нет — все артикулы есть в справочнике.", muted)
    for c, w in enumerate([30, 12, 11, 11, 9, 11, 10, 11, 11, 14, 13, 14, 11, 30]):
        ws.set_column(c, c, w)
    ws.freeze_panes(hr + 1, 1)
    _print_wide(ws, repeat_header=False)
    return first + 1, last + 1


# ---------- лист «Сводка» ----------
def _summary_sheet(b: _Book, ws, rep: Report, result: Result, company: str, checks: tuple[int, int],
                   created: datetime) -> None:
    ws.hide_gridlines(2)
    ws.set_column(0, 0, 2)
    ws.set_column(1, 12, 13.5)
    ws.set_column(13, 13, 2)
    t, stores = rep.total, rep.stores
    ws.set_row(0, 12)
    ws.set_row(1, 30)
    ws.write_string(1, 1, f"Продажи за {month_name(rep.month)}", b.f(bold=True, font_size=18))
    sub = f"{company} · {', '.join(result.sources)} · отчёт собран {created:%d.%m.%Y в %H:%M}"
    ws.write_string(2, 1, sub, b.f(font_color=MUTED))
    # строки таблицы магазинов: нужны карточкам выше
    s_hdr, s_first = 9, 10
    s_tot = s_first + len(stores)  # индекс строки «Итого» (0-based)
    X = s_tot + 1  # номер строки «Итого» в Excel

    # карточки
    card = {"bg_color": CARD, "left": 5, "right": 5, "left_color": "#FFFFFF", "right_color": "#FFFFFF"}
    lab = b.f(**card, font_color=MUTED, font_size=9, indent=1)
    val = b.f(**card, bold=True, font_size=18, indent=1, num_format=MONEY)
    note = b.f(**card, font_color=MUTED, font_size=9, indent=1)
    ws.set_row(3, 8)
    ws.set_row(4, 20)
    ws.set_row(5, 30)
    ws.set_row(6, 20)
    cards = [
        ("Выручка", f"=C{X}", t.revenue, MONEY, f"=SUMIFS({T}[Сумма],{T}[Операция],\"{SALE}\")",
         t.sales, '"продажи "#,##0" ₽ минус возвраты"'),
        ("Валовая прибыль", f"=H{X}", t.profit, MONEY, f"=I{X}", t.margin, '"маржа "0.0%'),
        ("Чеков", f"=E{X}", t.receipts, INT, f"=F{X}", t.avg_receipt, '"средний чек "#,##0" ₽"'),
        ("Возвраты", f"=G{X}", t.returns, MONEY, f"=IF(C{X}+G{X}>0,G{X}/(C{X}+G{X}),0)",
         t.returns / t.sales if t.sales else 0.0, '0.0%" от продаж"'),
    ]
    for k, (label, fv, v, nf, fs, vs, nfs) in enumerate(cards):
        c0, c1 = 1 + 3 * k, 3 + 3 * k
        ws.merge_range(4, c0, 4, c1, label, lab)
        ws.merge_range(5, c0, 5, c1, "", val)
        b.formula(ws, 5, c0, fv, b.f(**card, bold=True, font_size=18, indent=1, num_format=nf), v)
        ws.merge_range(6, c0, 6, c1, "", note)
        b.formula(ws, 6, c0, fs, b.f(**card, font_color=MUTED, font_size=9, indent=1, num_format=nfs), vs)

    # по магазинам
    sec = b.f(bold=True, font_size=11)
    ws.set_row(7, 14)
    ws.write_string(8, 1, "По магазинам", sec)
    heads = ["Магазин", "Выручка", "Доля", "Чеков", "Средний чек", "Возвраты", "Прибыль", "Маржа"]
    for c, h in enumerate(heads):
        ws.write_string(s_hdr, 1 + c, h, b.f(bold=True, font_color=MUTED, font_size=9, bottom=1, bottom_color=LINE,
                                               align="left" if c == 0 else "right"))
    row = {"bottom": 1, "bottom_color": LINE}
    ftext, fmoney, fpct, fint = b.f(**row), b.f(**row, num_format=MONEY), b.f(**row, num_format=PCT), \
        b.f(**row, num_format=INT)
    for i, (name, st) in enumerate(stores):
        r, x = s_first + i, s_first + i + 1
        ws.write_string(r, 1, name, ftext)
        crit = f"{T}[Магазин],$B{x}"
        b.formula(ws, r, 2, f"=SUMIFS({T}[Сумма],{crit})", fmoney, st.revenue)
        b.formula(ws, r, 3, f"=IF($C${X}<>0,C{x}/$C${X},0)", fpct, st.revenue / t.revenue if t.revenue else 0.0)
        b.formula(ws, r, 4, f"=SUMIFS({T}[Чеков],{crit})", fint, st.receipts)
        b.formula(ws, r, 5, f'=IF(E{x}>0,SUMIFS({T}[Сумма],{crit},{T}[Операция],"{SALE}")/E{x},0)', fmoney,
                  st.avg_receipt)
        b.formula(ws, r, 6, f'=-SUMIFS({T}[Сумма],{crit},{T}[Операция],"{RETURN}")', fmoney, st.returns)
        b.formula(ws, r, 7, f"=SUMIFS({T}[Прибыль],{crit})", fmoney, st.profit)
        b.formula(ws, r, 8, f'=IF(SUMIFS({T}[Сумма],{crit},{T}[Себестоимость],"<>")<>0,'
                            f'H{x}/SUMIFS({T}[Сумма],{crit},{T}[Себестоимость],"<>"),"")', fpct, st.margin)
    tot = {"bold": True, "top": 1, "top_color": INK}
    a, z = s_first + 1, s_tot
    ws.write_string(s_tot, 1, "Итого", b.f(**tot))
    b.formula(ws, s_tot, 2, f"=SUM(C{a}:C{z})", b.f(**tot, num_format=MONEY), t.revenue)
    b.formula(ws, s_tot, 3, f"=SUM(D{a}:D{z})", b.f(**tot, num_format=PCT), 1.0 if t.revenue else 0.0)
    b.formula(ws, s_tot, 4, f"=SUM(E{a}:E{z})", b.f(**tot, num_format=INT), t.receipts)
    b.formula(ws, s_tot, 5, f'=IF(E{X}>0,SUMIFS({T}[Сумма],{T}[Операция],"{SALE}")/E{X},0)',
              b.f(**tot, num_format=MONEY), t.avg_receipt)
    b.formula(ws, s_tot, 6, f"=SUM(G{a}:G{z})", b.f(**tot, num_format=MONEY), t.returns)
    b.formula(ws, s_tot, 7, f"=SUM(H{a}:H{z})", b.f(**tot, num_format=MONEY), t.profit)
    b.formula(ws, s_tot, 8, f'=IF(SUMIFS({T}[Сумма],{T}[Себестоимость],"<>")<>0,'
                            f'H{X}/SUMIFS({T}[Сумма],{T}[Себестоимость],"<>"),"")',
              b.f(**tot, num_format=PCT), t.margin)

    # сверка с выгрузками — справа от магазинов; цифры берутся с листа «Проверки»
    _check_panel(b, ws, result, checks)

    # график по дням
    r = max(s_tot + 2, 15)
    ws.write_string(r, 1, "Выручка по дням, ₽", sec)
    n_days = len(rep.days)
    chart = b.wb.add_chart({"type": "column", "subtype": "stacked"})
    for j in range(1, len(result.sources) + 1):
        chart.add_series({"name": ["По дням", 0, j], "categories": ["По дням", 1, 0, n_days, 0],
                          "values": ["По дням", 1, j, n_days, j], "gap": 45,
                          "fill": {"color": STORE_COLORS[(j - 1) % len(STORE_COLORS)]}, "border": {"none": True}})
    axis_font = {"name": FONT, "size": 8, "color": MUTED}
    chart.set_x_axis({"num_format": "d", "num_font": axis_font, "line": {"color": LINE},
                      "major_tick_mark": "none", "date_axis": False})
    chart.set_y_axis({"num_format": '#,##0', "num_font": axis_font, "line": {"none": True},
                      "major_gridlines": {"visible": True, "line": {"color": "#ECEBE6"}}})
    chart.set_legend({"position": "top", "font": {"name": FONT, "size": 9, "color": INK}})
    chart.set_chartarea({"border": {"none": True}})
    chart.set_plotarea({"border": {"none": True}})
    chart.set_size({"width": 1180, "height": 300})
    ws.insert_chart(r + 1, 1, chart, {"x_offset": 2, "y_offset": 4, "object_position": 1})

    # категории и топ-5
    r += 18
    ws.write_string(r, 1, "По категориям", sec)
    ws.write_string(r, 7, "Топ-5 товаров по выручке", sec)
    r += 1
    for c, h in enumerate(["Категория", "Выручка", "Доля", "Прибыль", "Маржа"]):
        ws.write_string(r, 1 + c, h, b.f(bold=True, font_color=MUTED, font_size=9, bottom=1, bottom_color=LINE,
                                         align="left" if c == 0 else "right"))
    ws.merge_range(r, 7, r, 9, "Товар", b.f(bold=True, font_color=MUTED, font_size=9, bottom=1, bottom_color=LINE))
    for c, h in ((10, "Выручка"), (11, "Доля"), (12, "ABC")):
        ws.write_string(r, c, h, b.f(bold=True, font_color=MUTED, font_size=9, bottom=1, bottom_color=LINE,
                                     align="center" if c == 12 else "right"))
    c_first = r + 1
    c_total_x = c_first + len(rep.categories) + 1  # Excel-номер строки «Итого» категорий
    for i, cat in enumerate(rep.categories.itertuples(index=False)):
        rr, x = c_first + i, c_first + i + 1
        ws.write_string(rr, 1, cat.category, ftext)
        crit = f"{T}[Категория],$B{x}"
        b.formula(ws, rr, 2, f"=SUMIFS({T}[Сумма],{crit})", fmoney, cat.revenue)
        b.formula(ws, rr, 3, f"=IF($C${c_total_x}<>0,C{x}/$C${c_total_x},0)", fpct, cat.share)
        b.formula(ws, rr, 4, f'=IF(COUNTIFS({crit},{T}[Себестоимость],"<>")=0,"",SUMIFS({T}[Прибыль],{crit}))',
                  fmoney, cat.profit)
        b.formula(ws, rr, 5, f'=IF(SUMIFS({T}[Сумма],{crit},{T}[Себестоимость],"<>")<>0,'
                             f'E{x}/SUMIFS({T}[Сумма],{crit},{T}[Себестоимость],"<>"),"")', fpct, cat.margin)
    ct = c_total_x - 1
    ws.write_string(ct, 1, "Итого", b.f(**tot))
    cats = rep.categories
    b.formula(ws, ct, 2, f"=SUM(C{c_first + 1}:C{ct})", b.f(**tot, num_format=MONEY), float(cats.revenue.sum()))
    b.formula(ws, ct, 3, f"=SUM(D{c_first + 1}:D{ct})", b.f(**tot, num_format=PCT), float(cats.share.sum()))
    b.formula(ws, ct, 4, f"=SUM(E{c_first + 1}:E{ct})", b.f(**tot, num_format=MONEY),
              float(sum(v for v in cats.profit if v != "")))
    b.formula(ws, ct, 5, f"=I{X}", b.f(**tot, num_format=PCT), t.margin)

    top = rep.products.head(5)
    fabc = b.f(**row, align="center", bold=True)
    for i, p in enumerate(top.itertuples(index=False)):
        rr, src = c_first + i, i + 2
        ws.merge_range(rr, 7, rr, 9, "", ftext)
        b.formula(ws, rr, 7, f"='Товары'!B{src}", ftext, p.name)
        b.formula(ws, rr, 10, f"='Товары'!F{src}", fmoney, p.revenue)
        b.formula(ws, rr, 11, f"='Товары'!I{src}", fpct, p.share)
        b.formula(ws, rr, 12, f"='Товары'!K{src}", fabc, p.abc)

    r = ct + 3
    notes = b.f(font_color=MUTED, font_size=9)
    ws.write_string(r, 1, "Как считали", b.f(bold=True, font_size=9, font_color=MUTED))
    for k, line in enumerate([
        "Выручка — продажи минус возвраты. Средний чек — продажи, делённые на число чеков продажи.",
        "Прибыль — выручка минус себестоимость из справочника. Товары не из справочника в прибыль и маржу не входят.",
        "Все цифры — формулы по листу «Данные»: кликните по ячейке, чтобы увидеть, как она посчитана.",
    ], 1):
        ws.write_string(r + k, 1, line, notes)

    ws.set_landscape()
    ws.set_paper(9)
    ws.fit_to_pages(1, 1)
    ws.set_margins(left=0.4, right=0.4, top=0.5, bottom=0.5)
    ws.print_area(0, 0, r + 3, 13)
    ws.activate()


def _check_panel(b: _Book, ws, result: Result, checks: tuple[int, int]) -> None:
    c0, c1 = 10, 12  # K:M
    p1, p2 = checks
    rng = lambda col: f"'Проверки'!${col}${p1}:${col}${p2}"  # noqa: E731
    ws.write_string(8, c0, "Сверка с выгрузками", b.f(bold=True, font_size=11))
    badge = b.f(bold=True, align="center", font_size=9)
    ok = all(file_status(st).startswith(STATUS_OK) for st in result.files)
    ws.merge_range(9, c0, 9, c1, "", badge)
    b.formula(ws, 9, c0, f'=IF(COUNTIF({rng("N")},"{STATUS_OK}*")=ROWS({rng("N")}),"{BADGE_OK}","{BADGE_WARN}")',
              badge, BADGE_OK if ok else BADGE_WARN)
    for crit, bg, fg in (("✓", GOOD, "#1E5631"), ("!", WARN, "#7A4B00")):
        ws.conditional_format(9, c0, 9, c1, {"type": "text", "criteria": "begins with", "value": crit,
                                             "format": b.wb.add_format({"bg_color": bg, "font_color": fg})})
    files = result.files
    lines = [
        ("Строк в выгрузках", f"=SUM({rng('C')})", sum(st.rows for st in files)),
        ("Вошло в отчёт", f"=SUM({rng('D')})", sum(st.in_report for st in files)),
        ("Дубли", f"=SUM({rng('E')})", sum(st.duplicates for st in files)),
        ("Другой месяц и отмены", f"=SUM({rng('F')})+SUM({rng('G')})",
         sum(st.outside + st.cancelled for st in files)),
        ("С ошибками", f"=SUM({rng('H')})", sum(st.errors for st in files)),
    ]
    row = {"bottom": 1, "bottom_color": LINE}
    for k, (label, formula, value) in enumerate(lines):
        r = 10 + k
        ws.merge_range(r, c0, r, c1 - 1, label, b.f(**row))
        b.formula(ws, r, c1, formula, b.f(**row, num_format=INT), value)
    ws.conditional_format(14, c1, 14, c1, {"type": "cell", "criteria": ">", "value": 0,
                                           "format": b.wb.add_format({"bg_color": WARN, "bold": True})})


def write_report(result: Result, path: Path, company: str, abc_a: float = 0.8, abc_b: float = 0.95,
                 created: datetime | None = None, cached: bool = True) -> Report:
    rep = aggregate(result, abc_a, abc_b)
    created = created or datetime.now()
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    b = _Book(path, cached)
    b.wb.set_properties({"title": f"{company} — продажи за {month_name(rep.month)}", "author": company,
                         "comments": "Собрано скриптом polka-report из выгрузок касс и сайта"})
    sheets = {name: b.wb.add_worksheet(name) for name in ("Сводка", "По дням", "Товары", "Проверки", "Данные")}
    _days_sheet(b, sheets["По дням"], rep, list(result.sources))
    _products_sheet(b, sheets["Товары"], rep, abc_a, abc_b)
    checks = _checks_sheet(b, sheets["Проверки"], result)
    _data_sheet(b, sheets["Данные"], result.rows)
    _summary_sheet(b, sheets["Сводка"], rep, result, company, checks, created)
    b.wb.close()
    return rep
