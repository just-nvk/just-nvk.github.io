"""Из сырых строк выгрузок — одна чистая таблица продаж и журнал всего, что не вошло в отчёт."""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path

import pandas as pd

from .config import Config, ConfigError
from .parse import clean_text, is_blank, normalize_sku, parse_date, parse_number
from .readers import RawFile, find_files, read_catalog, read_export

SALE, RETURN = "Продажа", "Возврат"
NO_CATEGORY = "Без категории"
COLUMNS = ["date", "source", "receipt", "line", "sku", "name", "category", "kind", "qty", "amount", "cost",
           "profit", "new_receipt", "file", "file_row"]


@dataclass
class FileStats:
    file: str
    source: str
    rows: int = 0  # строк с данными в файле (без шапки, пустых строк и «Итого»)
    in_report: int = 0
    duplicates: int = 0
    outside: int = 0
    cancelled: int = 0
    errors: int = 0
    other_amount: float = 0.0  # сумма строк, которые не вошли в отчёт, но посчитаны: дубли, другой месяц, отмены
    stated_total: float | None = None
    report_amount: float = 0.0


@dataclass
class Issue:
    file: str
    row: int
    reason: str
    raw: str


@dataclass
class Result:
    month: tuple[int, int]
    rows: pd.DataFrame
    files: list[FileStats]
    issues: list[Issue] = field(default_factory=list)
    unknown: pd.DataFrame = field(default_factory=pd.DataFrame)  # артикулы, которых нет в справочнике
    sources: tuple[str, ...] = ()


def _raw_text(record: dict) -> str:
    return " · ".join(clean_text(v) for v in record.values() if not is_blank(v))


def _parse_row(record: dict, source) -> tuple[dict | None, str | None]:
    """Одна строка выгрузки → словарь или текст ошибки. kind = None значит «отменено, не считать»."""
    d = parse_date(record["date"])
    if d is None:
        return None, "нет даты" if is_blank(record["date"]) else f"дата «{clean_text(record['date'])}» не распознана"
    receipt = clean_text(record["receipt"])
    if not receipt:
        return None, "нет номера чека"
    sku = normalize_sku(record["sku"])
    if not sku:
        return None, "нет артикула"
    qty = parse_number(record["qty"])
    if qty is None:
        return None, f"количество «{clean_text(record['qty'])}» — не число"
    amount = parse_number(record["amount"])
    if amount is None:
        return None, "нет суммы" if is_blank(record["amount"]) else f"сумма «{clean_text(record['amount'])}» — не число"

    if "operation" in record:
        op = clean_text(record["operation"]).lower()
        if op in source.skip:
            kind = None
        elif op in source.returns:
            kind = RETURN
        elif not source.sales or op in source.sales:
            kind = SALE
        else:
            return None, f"неизвестная операция «{clean_text(record['operation'])}» — добавьте её в [source.operations]"
    else:
        kind = RETURN if amount < 0 or qty < 0 else SALE
    if kind == RETURN:
        qty, amount = -abs(qty), -abs(amount)
    return {"date": d, "receipt": receipt, "line": clean_text(record.get("line")), "sku": sku,
            "name": clean_text(record.get("name")), "kind": kind, "qty": qty, "amount": round(amount, 2)}, None


def _line_key(line: str):
    return (0, int(line), "") if line.isdigit() else (1, 0, line)


def build(raw_files: list[RawFile], catalog: dict[str, dict], month: tuple[int, int] | None = None) -> Result:
    stats, issues, parsed = [], [], []
    for raw in raw_files:
        st = FileStats(file=raw.name, source=raw.source.name, rows=len(raw.rows), stated_total=raw.stated_total)
        stats.append(st)
        for line, record in raw.rows:
            row, error = _parse_row(record, raw.source)
            if error:
                st.errors += 1
                issues.append(Issue(raw.name, line, error, _raw_text(record)))
                continue
            row.update(source=raw.source.name, file=raw.name, file_row=line)
            parsed.append((st, row))

    if month is None:
        months = Counter((r["date"].year, r["date"].month) for st, r in parsed if r["kind"])
        if not months:
            raise ConfigError("В выгрузках нет ни одной строки, которую можно посчитать — проверьте файлы и настройки")
        month = months.most_common(1)[0][0]

    seen, rows, occurrence = set(), [], Counter()
    for st, r in parsed:
        line = (r["source"], r["receipt"], r["line"], r["sku"], r["qty"], r["amount"], r["date"], r["kind"])
        # Одинаковые строки внутри одного файла — разные покупки (две кружки одним чеком без номера позиции).
        # Дубль — это та же строка, пришедшая из другого файла: выгрузки пересекаются на стыке периодов.
        occurrence[id(st), line] += 1
        key = (*line, occurrence[id(st), line])
        if key in seen:
            st.duplicates += 1
            st.other_amount += r["amount"]
            continue
        seen.add(key)
        if (r["date"].year, r["date"].month) != month:
            st.outside += 1
            st.other_amount += r["amount"]
        elif r["kind"] is None:
            st.cancelled += 1
            st.other_amount += r["amount"]
        else:
            st.in_report += 1
            st.report_amount += r["amount"]
            rows.append(r)

    unknown: dict[str, dict] = {}
    for r in rows:
        item = catalog.get(r["sku"])
        if item:
            r["name"], r["category"], r["cost"] = item["name"] or r["name"], item["category"], item["cost"]
        else:
            u = unknown.setdefault(r["sku"], {"sku": r["sku"], "name": r["name"], "rows": 0, "amount": 0.0})
            u["rows"] += 1
            u["amount"] += r["amount"]
            r["category"], r["cost"] = NO_CATEGORY, None
        r["profit"] = None if r["cost"] is None else r["amount"] - r["qty"] * r["cost"]

    order = sorted(rows, key=lambda r: (r["date"], r["source"], r["receipt"], _line_key(r["line"])))
    first = set()
    for r in order:  # «Новый чек» = 1 у первой строки каждого чека продажи: по этой колонке считаем чеки
        key = (r["source"], r["receipt"])
        r["new_receipt"] = 1 if r["kind"] == SALE and key not in first else 0
        if r["kind"] == SALE:
            first.add(key)

    for st in stats:
        st.other_amount = round(st.other_amount, 2)
        st.report_amount = round(st.report_amount, 2)
    frame = pd.DataFrame(order, columns=COLUMNS)
    unknown_df = pd.DataFrame(sorted(unknown.values(), key=lambda u: -u["amount"]),
                              columns=["sku", "name", "rows", "amount"])
    sources = tuple(dict.fromkeys(s.source for s in stats))
    return Result(month=month, rows=frame, files=stats, issues=issues, unknown=unknown_df, sources=sources)


def load_all(config: Config, folder: Path | None = None, month: tuple[int, int] | None = None) -> Result:
    folder = Path(folder or config.exports)
    if not folder.is_dir():
        raise ConfigError(f"Не нашёл папку с выгрузками {folder}")
    raw_files = []
    for source in config.sources:
        files = find_files(folder, source)
        if not files:
            raise ConfigError(f"Для «{source.name}» нет файлов {source.files} в папке {folder}")
        raw_files += [read_export(p, source) for p in files]
    result = build(raw_files, read_catalog(config.catalog), month)
    result.sources = tuple(s.name for s in config.sources)
    return result
