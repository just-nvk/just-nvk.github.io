"""python -m polka_report [--in папка] [--month 2026-10] — собрать отчёт по выгрузкам."""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
from datetime import datetime
from pathlib import Path

from .clean import load_all
from .config import ConfigError, load
from .parse import month_name, num, parse_month, plural, rub
from .report import report_name, write_report


def _open(path: Path) -> None:
    if sys.platform.startswith("win"):
        os.startfile(path)  # type: ignore[attr-defined]  # noqa: S606
    else:
        subprocess.run(["open" if sys.platform == "darwin" else "xdg-open", str(path)], check=False)


def run(argv: list[str] | None = None, now: datetime | None = None) -> int:
    ap = argparse.ArgumentParser(prog="python -m polka_report", description="Собрать Excel-отчёт по выгрузкам продаж.")
    ap.add_argument("--config", default="polka.toml", help="файл настроек (по умолчанию polka.toml)")
    ap.add_argument("--in", dest="folder", help="папка с выгрузками (по умолчанию — из настроек)")
    ap.add_argument("--month", help="месяц отчёта, например 2026-10 "
                                    "(по умолчанию — тот, за который больше всего строк)")
    ap.add_argument("--out", help="папка для отчёта (по умолчанию — из настроек)")
    ap.add_argument("--open", action="store_true", help="открыть отчёт после сборки")
    args = ap.parse_args(argv)
    if sys.stdout.encoding and sys.stdout.encoding.lower() not in ("utf-8", "utf8"):
        sys.stdout.reconfigure(encoding="utf-8")  # консоль Windows

    try:
        config = load(Path(args.config))
        month = parse_month(args.month) if args.month else None
        result = load_all(config, Path(args.folder) if args.folder else None, month)
        out_dir = Path(args.out) if args.out else config.reports
        path = out_dir / report_name(config.company, result.month)
        try:
            rep = write_report(result, path, config.company, config.abc_a, config.abc_b, created=now)
        except PermissionError:
            raise ConfigError(f"Не могу сохранить {path.name}: файл открыт в Excel. "
                              "Закройте его и запустите снова.") from None
    except (ConfigError, ValueError) as e:
        print(f"Ошибка: {e}", file=sys.stderr)
        return 2

    t = rep.total
    print(f"{config.company} · продажи за {month_name(result.month)}\n")
    n = len(result.files)
    print(f"Прочитано {n} {plural(n, 'файл', 'файла', 'файлов')}:")
    width = max(len(s.file) for s in result.files)
    for s in result.files:
        print(f"  {s.file:<{width}}  {num(s.rows):>6} {plural(s.rows, 'строка', 'строки', 'строк'):<6}  {s.source}")
    dup, out, canc, err = (sum(getattr(s, k) for s in result.files)
                           for k in ("duplicates", "outside", "cancelled", "errors"))
    print(f"\nВ отчёте {num(len(result.rows))} {plural(len(result.rows), 'строка', 'строки', 'строк')}. "
          f"Дубли: {num(dup)} · другой месяц: {num(out)} · отменены: {num(canc)} · с ошибками: {num(err)}")
    margin = f" ({t.margin:.1%})".replace(".", ",") if t.margin != "" else ""
    print(f"Выручка {rub(t.revenue)} · прибыль {rub(t.profit)}{margin} · чеков {num(t.receipts)}")

    if result.issues:
        print(f"\n! Проверьте строки с ошибками ({len(result.issues)}) — лист «Проверки»:")
        for i in result.issues[:5]:
            print(f"  {i.file}, строка {i.row}: {i.reason}")
        if len(result.issues) > 5:
            print(f"  … и ещё {len(result.issues) - 5}")
    if len(result.unknown):
        items = ", ".join(f"{u.sku} «{u.name}»" for u in result.unknown.head(3).itertuples())
        print(f"! Нет в справочнике: {items} — прибыль по ним не посчитана")
    print(f"\nОтчёт: {path}")
    if args.open:
        _open(path)
    return 0


def main() -> None:
    sys.exit(run())


if __name__ == "__main__":
    main()
