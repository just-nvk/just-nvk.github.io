"""Итоги для отчёта, посчитанные в pandas. В Excel те же цифры считают формулы — эти значения нужны,
чтобы файл сразу показывал числа в любой программе, и чтобы тесты сверяли формулы с расчётом."""
from __future__ import annotations

import calendar
from dataclasses import dataclass
from datetime import date

import pandas as pd

from .clean import NO_CATEGORY, RETURN, SALE, Result


def _div(a: float, b: float):
    return a / b if b else ""


@dataclass
class Totals:
    revenue: float
    sales: float
    returns: float
    receipts: int
    avg_receipt: float
    profit: float
    margin: float | str
    days: int


def _totals(rows: pd.DataFrame, days: int) -> Totals:
    sales = float(rows.loc[rows.kind == SALE, "amount"].sum())
    receipts = int(rows.new_receipt.sum())
    costed = rows[rows.cost.notna()]
    profit = float(costed.profit.sum())
    returns = -float(rows.loc[rows.kind == RETURN, "amount"].sum())
    return Totals(revenue=float(rows.amount.sum()), sales=sales, returns=returns,
                  receipts=receipts, avg_receipt=sales / receipts if receipts else 0.0, profit=profit,
                  margin=_div(profit, float(costed.amount.sum())), days=days)


@dataclass
class Report:
    month: tuple[int, int]
    total: Totals
    stores: list[tuple[str, Totals]]
    days: pd.DataFrame  # дата × магазин
    products: pd.DataFrame
    categories: pd.DataFrame


def aggregate(result: Result, abc_a: float = 0.8, abc_b: float = 0.95) -> Report:
    rows = result.rows
    year, month = result.month
    n_days = calendar.monthrange(year, month)[1]
    total = _totals(rows, n_days)
    stores = [(s, _totals(rows[rows.source == s], n_days)) for s in result.sources]

    dates = [date(year, month, d) for d in range(1, n_days + 1)]
    days = (rows.pivot_table(index="date", columns="source", values="amount", aggfunc="sum")
            .reindex(index=dates, columns=list(result.sources)).fillna(0.0))

    def product(g: pd.DataFrame) -> pd.Series:
        costed = g[g.cost.notna()]
        return pd.Series({
            "name": g["name"].iloc[0], "category": g["category"].iloc[0],
            "sold": float(g.loc[g.kind == SALE, "qty"].sum()), "returned": -float(g.loc[g.kind == RETURN, "qty"].sum()),
            "revenue": float(g.amount.sum()),
            "profit": float(costed.profit.sum()) if len(costed) else "",
        })

    if len(rows):
        products = rows.groupby("sku", sort=False)[["name", "category", "kind", "qty", "amount", "cost", "profit"]] \
            .apply(product).reset_index()
    else:
        products = pd.DataFrame(columns=["sku", "name", "category", "sold", "returned", "revenue", "profit"])
    products = products.sort_values(["revenue", "sku"], ascending=[False, True], kind="stable").reset_index(drop=True)
    grand = float(products.revenue.sum())
    products["margin"] = [("" if p == "" or r <= 0 else p / r)
                          for p, r in zip(products.profit, products.revenue, strict=True)]
    products["share"] = products.revenue / grand if grand else 0.0
    products["cum"] = products.share.cumsum()
    prev = products.cum - products.share
    products["abc"] = ["A" if p < abc_a else "B" if p < abc_b else "C" for p in prev]

    cats = []
    for cat, g in rows.groupby("category"):
        costed = g[g.cost.notna()]
        profit = float(costed.profit.sum()) if len(costed) else ""  # без себестоимости прибыль не известна
        cats.append({"category": cat, "revenue": float(g.amount.sum()), "profit": profit,
                     "margin": _div(profit, float(costed.amount.sum())) if len(costed) else ""})
    categories = pd.DataFrame(cats, columns=["category", "revenue", "profit", "margin"])
    # «Без категории» — в конце: это товары не из справочника
    categories["_last"] = categories.category == NO_CATEGORY
    categories = (categories.sort_values(["_last", "revenue"], ascending=[True, False])
                  .drop(columns="_last").reset_index(drop=True))
    categories["share"] = categories.revenue / total.revenue if total.revenue else 0.0
    return Report(month=result.month, total=total, stores=stores, days=days, products=products, categories=categories)
