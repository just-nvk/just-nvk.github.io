"""Чтение выгрузок: CSV в любой кодировке и с любым разделителем, Excel с шапкой не в первой строке."""
from __future__ import annotations

import csv
import io
from dataclasses import dataclass, field
from pathlib import Path

from openpyxl import load_workbook

from .config import FIELDS, Catalog, ConfigError, Source
from .parse import clean_text, is_blank, normalize_sku, parse_number

HEADER_SEARCH_ROWS = 20  # шапку таблицы ищем в первых строках: выше неё бывают заголовок и период


@dataclass
class RawFile:
    """Строки одной выгрузки как есть: поле → значение, плюс номер строки в файле."""
    path: Path
    source: Source
    rows: list[tuple[int, dict]] = field(default_factory=list)
    stated_total: float | None = None  # строка «Итого» из самой выгрузки, если есть

    @property
    def name(self) -> str:
        return self.path.name


def _norm(s) -> str:
    return clean_text(s).lower().replace("ё", "е")


def _decode(data: bytes, encoding: str | None) -> str:
    if encoding:
        return data.decode(encoding)
    try:
        return data.decode("utf-8-sig")
    except UnicodeDecodeError:
        return data.decode("cp1251")  # выгрузки старых касс и 1С


def _delimiter(text: str, configured: str | None) -> str:
    if configured:
        return "\t" if configured == "\\t" else configured
    sample = "\n".join(text.splitlines()[:30])
    try:
        return csv.Sniffer().sniff(sample, delimiters=";,\t|").delimiter
    except csv.Error:
        return ";"


def _table_rows(path: Path, source: Source):
    """(номер строки в файле, список ячеек) для CSV и Excel."""
    suffix = path.suffix.lower()
    if suffix in (".xlsx", ".xlsm"):
        wb = load_workbook(path, read_only=True, data_only=True)
        try:
            ws = wb[source.sheet] if source.sheet else wb.worksheets[0]
        except KeyError:
            raise ConfigError(f"В файле {path.name} нет листа «{source.sheet}». "
                              f"Листы: {', '.join(wb.sheetnames)}") from None
        for i, row in enumerate(ws.iter_rows(values_only=True), 1):
            yield i, list(row)
        wb.close()
    elif suffix in (".csv", ".txt", ".tsv"):
        text = _decode(path.read_bytes(), source.encoding)
        reader = csv.reader(io.StringIO(text, newline=""), delimiter=_delimiter(text, source.delimiter))
        line = 1
        for cells in reader:
            yield line, cells
            line = reader.line_num + 1
    else:
        raise ConfigError(f"Файл {path.name}: умею читать CSV и XLSX. Старый .xls пересохраните в Excel как .xlsx")


def _find_header(rows, columns: dict[str, str], labels: dict[str, str], path: Path, hint: str):
    wanted = {f: _norm(t) for f, t in columns.items()}
    best, best_hits = None, -1
    for idx, (_, cells) in enumerate(rows[:HEADER_SEARCH_ROWS]):
        titles = [_norm(c) for c in cells]
        hits = sum(1 for t in wanted.values() if t in titles)
        if hits == len(wanted):
            return idx, {f: titles.index(t) for f, t in wanted.items()}
        if hits > best_hits:
            best, best_hits = (idx, titles), hits
    found = [clean_text(c) for c in rows[best[0]][1] if not is_blank(c)] if best else []
    titles = best[1] if best else []
    missing = [f"«{columns[f]}» ({labels[f]})" for f, t in wanted.items() if t not in titles]
    raise ConfigError(
        f"В файле {path.name} нет колонок: {', '.join(missing)}.\n"
        f"Колонки в файле: {', '.join(found) or 'не нашёл шапку таблицы'}.\n"
        f"Поправьте {hint} в polka.toml.")


def read_export(path: Path, source: Source) -> RawFile:
    rows = list(_table_rows(path, source))
    header_idx, index = _find_header(rows, source.columns, FIELDS, path, f"раздел [source.columns] для «{source.name}»")
    raw = RawFile(path=path, source=source)
    first_cols = sorted(index.values())[:3]
    for line, cells in rows[header_idx + 1:]:
        if all(is_blank(c) for c in cells):
            continue
        record = {f: (cells[i] if i < len(cells) else None) for f, i in index.items()}
        lead = [_norm(cells[i]) for i in range(min(len(cells), max(first_cols) + 1))]
        if any(t.startswith("итого") or t.startswith("всего") for t in lead):
            raw.stated_total = parse_number(record["amount"])
            continue
        raw.rows.append((line, record))
    return raw


def find_files(folder: Path, source: Source) -> list[Path]:
    return sorted(p for p in Path(folder).glob(source.files) if p.is_file() and not p.name.startswith("~$"))


def read_catalog(catalog: Catalog) -> dict[str, dict]:
    """Справочник: артикул → название, категория, себестоимость."""
    if not catalog.file.is_file():
        raise ConfigError(f"Не нашёл справочник товаров {catalog.file}")
    src = Source(name="Справочник", files=catalog.file.name, columns=catalog.columns)
    rows = list(_table_rows(catalog.file, src))
    labels = {"sku": "артикул", "name": "название", "category": "категория", "cost": "себестоимость"}
    header_idx, index = _find_header(rows, catalog.columns, labels, catalog.file, "раздел [catalog.columns]")
    items = {}
    for _, cells in rows[header_idx + 1:]:
        cell = {f: (cells[i] if i < len(cells) else None) for f, i in index.items()}
        sku = normalize_sku(cell["sku"])
        if sku:
            items[sku] = {"name": clean_text(cell["name"]), "category": clean_text(cell["category"]) or "Без категории",
                          "cost": parse_number(cell["cost"])}
    return items


